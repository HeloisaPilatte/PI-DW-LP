/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Heloisa
 */
@Entity
@Table(name = "cadastro")
@NamedQueries({
    @NamedQuery(name = "Cadastro.findAll", query = "SELECT c FROM Cadastro c")})
public class Cadastro implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "cnpj_cadastro")
    private Integer cnpjCadastro;
    @Column(name = "nome_cadastro")
    private String nomeCadastro;
    @Column(name = "email_cadastro")
    private String emailCadastro;
    @Column(name = "senha_cadastro")
    private String senhaCadastro;

    public Cadastro() {
    }

    public Cadastro(Integer cnpjCadastro) {
        this.cnpjCadastro = cnpjCadastro;
    }

    public Integer getCnpjCadastro() {
        return cnpjCadastro;
    }

    public void setCnpjCadastro(Integer cnpjCadastro) {
        this.cnpjCadastro = cnpjCadastro;
    }

    public String getNomeCadastro() {
        return nomeCadastro;
    }

    public void setNomeCadastro(String nomeCadastro) {
        this.nomeCadastro = nomeCadastro;
    }

    public String getEmailCadastro() {
        return emailCadastro;
    }

    public void setEmailCadastro(String emailCadastro) {
        this.emailCadastro = emailCadastro;
    }

    public String getSenhaCadastro() {
        return senhaCadastro;
    }

    public void setSenhaCadastro(String senhaCadastro) {
        this.senhaCadastro = senhaCadastro;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cnpjCadastro != null ? cnpjCadastro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cadastro)) {
            return false;
        }
        Cadastro other = (Cadastro) object;
        if ((this.cnpjCadastro == null && other.cnpjCadastro != null) || (this.cnpjCadastro != null && !this.cnpjCadastro.equals(other.cnpjCadastro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return (cnpjCadastro+";"+nomeCadastro+";"+emailCadastro+";"+senhaCadastro+"<br/>");
    }
    
}
