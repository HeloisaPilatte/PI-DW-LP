package daos;

import Entidades.Venda;
import Entidades.VendaHasProduto;
import java.util.ArrayList;
import java.util.List;

public class DAOVenda extends DAOGenerico<Venda> {

    public DAOVenda() {
        super(Venda.class);
    }

    public int autoIdVenda() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idVenda) FROM Venda e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Venda> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Venda e WHERE e.nomeVenda LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Venda> listById(int id) {
        return em.createQuery("SELECT e FROMVenda  e WHERE e.idVenda = :id").setParameter("id", id).getResultList();
    }

    public List<Venda> listInOrderNome() {
        return em.createQuery("SELECT e FROM Venda e ORDER BY e.nomeVenda").getResultList();
    }
    
    public List<VendaHasProduto> vendaHasProdutoListExtra(int id) {
        return em.createQuery("SELECT e FROM VendaHasProduto e WHERE e.vendaHasProdutoPK.vendaIdVenda = :id").
                setParameter("id", id).getResultList();
    }

   public List<String> listInOrderNomeStrings() {
        List<Venda> lf = listInOrderNome();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdVenda() + "-" + lf.get(i).getNomeVenda());
        }
        return ls;
    }

    public String[] listInOrderNomeVetorStrings() {
        List<Venda> lf = listInOrderNome();
        String[] vet = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            vet[i] = lf.get(i).getIdVenda() + "-" + lf.get(i).getNomeVenda();
        }
        return vet;
    }
}
