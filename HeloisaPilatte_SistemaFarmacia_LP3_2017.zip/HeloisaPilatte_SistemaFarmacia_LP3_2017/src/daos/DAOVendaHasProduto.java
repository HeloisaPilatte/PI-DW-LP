/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import Entidades.VendaHasProduto;
import Entidades.VendaHasProdutoPK;
import static daos.DAOGenerico.em;
import java.util.ArrayList;
import java.util.List;


public class DAOVendaHasProduto extends DAOGenerico<VendaHasProduto> {

    public DAOVendaHasProduto() {
        super(VendaHasProduto.class);
    }
    
    public VendaHasProduto obter(VendaHasProdutoPK vendaHasProdutoPk) {
        return em.find(VendaHasProduto.class, vendaHasProdutoPk);
    }


    public List<VendaHasProduto> listByIdVenda(int id) {
        return em.createQuery("SELECT e FROM VendaHasProduto e WHERE e.vendaHasProdutoPK.vendaIdVenda = :id").setParameter("id", id).getResultList();
    }
    
    public List<VendaHasProduto> listByIdProduto(int id) {
        return em.createQuery("SELECT e FROM VendaHasProduto e WHERE e.vendaHasProdutoPK.produtoIdProduto = :id").setParameter("id", id).getResultList();
    }
    
    
    public List<VendaHasProduto> listInOrderVenda() {
        return em.createQuery("SELECT e FROM VendaHasProduto e ORDER BY e.vendaHasProdutoPK.vendaIdVenda").getResultList();
    }
    
    public List<VendaHasProduto> listInOrderProduto() {
        return em.createQuery("SELECT e FROM VendaHasProduto e ORDER BY e.vendaHasProdutoPK.produtoIdProduto").getResultList();
    }

    public List<String> listStrings() {
        List<VendaHasProduto> lf = listInOrderVenda();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(""+ lf.get(i).getVendaHasProdutoPK().getVendaIdVenda() + " - " + lf.get(i).getVendaHasProdutoPK().getProdutoIdProduto());
        }
        return ls;
    }
}

