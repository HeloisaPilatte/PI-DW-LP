
package daos;

import Entidades.VendaHasProduto;

public class DAOVendaHasProdutoPK extends DAOGenerico<VendaHasProduto> {
    public DAOVendaHasProdutoPK(){
    super(VendaHasProduto.class);
    }
    
}


