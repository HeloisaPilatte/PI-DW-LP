package GUIs;

import Entidades.Cliente;
import daos.DAOVenda;
import Entidades.Venda;
import daos.DAOCliente;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import tools.JanelaPesquisar;

public class GUIVenda extends JDialog {

    ImageIcon iconeCreate = new ImageIcon(getClass().getResource("/icones/create.png"));
    ImageIcon iconeRetrieve = new ImageIcon(getClass().getResource("/icones/retrieve.png"));
    ImageIcon iconeUpdate = new ImageIcon(getClass().getResource("/icones/update.png"));
    ImageIcon iconeDelete = new ImageIcon(getClass().getResource("/icones/delete.png"));
    ImageIcon iconeSave = new ImageIcon(getClass().getResource("/icones/save.png"));
    ImageIcon iconeCancel = new ImageIcon(getClass().getResource("/icones/cancel.png"));
    ImageIcon iconeListar = new ImageIcon(getClass().getResource("/icones/list.png"));
    private ImageIcon iconeFind = new ImageIcon(getClass().getResource("/icones/findCheck.png"));
    private ImageIcon iconeFindPequeno = new ImageIcon(getClass().getResource("/icones/find.png"));

    private JButton btnFind = new JButton(iconeFind);
    JButton btnCreate = new JButton(iconeCreate);
    JButton btnRetrieve = new JButton(iconeRetrieve);
    JButton btnUpdate = new JButton(iconeUpdate);
    JButton btnDelete = new JButton(iconeDelete);
    JButton btnSave = new JButton(iconeSave);
    JButton btnCancel = new JButton(iconeCancel);
    JButton btnList = new JButton(iconeListar);
    JLabel labelId = new JLabel("Id");
    JTextField textFieldId = new JTextField(50);
    JLabel labelNome = new JLabel("Nome Vendedor");
    JTextField textFieldNome = new JTextField(250);
    JLabel labelData = new JLabel("Data da Venda");
    JTextField textFieldData = new DateTextField();

    JLabel labelCliente_Id = new JLabel("Cliente");

    JPanel pnCliente = new JPanel();
    JTextField textFieldCliente = new JTextField(5);
    JButton btnC = new JButton(iconeFindPequeno);
    JPanel aviso = new JPanel();
    JLabel labelAviso = new JLabel("");
    String acao = "";

    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    DAOVenda daoVenda = new DAOVenda();
    Venda venda;
    DAOCliente daoCliente = new DAOCliente();
    Cliente cliente = new Cliente();

    List<String> listaC = daoCliente.listStrings();

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    private void atvBotoes(boolean c, boolean r, boolean u, boolean d) {
        btnCreate.setEnabled(c);
        btnFind.setEnabled(r);
        btnRetrieve.setEnabled(r);
        btnUpdate.setEnabled(u);
        btnDelete.setEnabled(d);
        btnList.setEnabled(r);
    }

    public void mostrarBotoes(boolean visivel) {
        btnCreate.setVisible(visivel);
        btnRetrieve.setVisible(visivel);
        btnUpdate.setVisible(visivel);
        btnDelete.setVisible(visivel);
        btnList.setVisible(visivel);
        btnSave.setVisible(!visivel);
        btnCancel.setVisible(!visivel);
        btnFind.setVisible(visivel);
    }

    private void habilitarAtributos(boolean id, boolean nome, boolean date, boolean cliente_id_cliente, boolean btnFindCli) {
        if (id) {
            textFieldId.requestFocus();
            textFieldId.selectAll();
        }
        textFieldId.setEnabled(id);
        textFieldId.setEditable(id);
        textFieldNome.setEditable(nome);
        textFieldData.setEditable(date);
        textFieldCliente.setEditable(cliente_id_cliente);
        btnC.setVisible(btnFindCli);

    }

    public void zerarAtributos() {
        textFieldNome.setText("");
        textFieldData.setText("");
        textFieldCliente.setText("");

    }

    public GUIVenda(Point p) {
        setTitle("Cadastro venda");
        setSize(500, 300);//tamanho da janela
        setLocation(p);
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

        atvBotoes(false, true, false, false);
        habilitarAtributos(true, false, false,false, false);
        btnCreate.setToolTipText("Inserir novo registro");
        btnRetrieve.setToolTipText("Pesquisar por chave");
        btnFind.setToolTipText("Pesquisar em lista");
        btnUpdate.setToolTipText("Alterar");
        btnDelete.setToolTipText("Excluir");
        btnList.setToolTipText("Listar todos");
        btnSave.setToolTipText("Salvar");
        btnCancel.setToolTipText("Cancelar");
        JToolBar Toolbar1 = new JToolBar();
        Toolbar1.add(labelId);
        Toolbar1.add(textFieldId);
        Toolbar1.add(btnFind);
        Toolbar1.add(btnRetrieve);
        Toolbar1.add(btnCreate);
        Toolbar1.add(btnUpdate);
        Toolbar1.add(btnDelete);
        Toolbar1.add(btnSave);
        Toolbar1.add(btnCancel);
        Toolbar1.add(btnList);

        btnSave.setVisible(false);
        btnCancel.setVisible(false);

        pnCliente.setLayout(new GridLayout(1, 2));
        pnCliente.add(textFieldCliente);
        pnCliente.add(btnC);

        JPanel centro = new JPanel();
        centro.setLayout(new GridLayout(5, 2));
        centro.add(labelId);
        centro.add(textFieldId);
        centro.add(labelNome);
        centro.add(textFieldNome);
        centro.add(labelData);
        centro.add(textFieldData);
        centro.add(labelCliente_Id);
        centro.add(pnCliente);

        aviso.add(labelAviso);
        aviso.setBackground(Color.yellow);
        cp.add(Toolbar1, BorderLayout.NORTH);
        cp.add(centro, BorderLayout.CENTER);
        cp.add(aviso, BorderLayout.SOUTH);
        textFieldId.requestFocus();
        textFieldId.selectAll();
        textFieldId.setBackground(Color.GREEN);
        labelAviso.setText("Digite uma id e clic [Pesquisar]");

        btnC.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                List<String> listaAuxiliar = daoCliente.listStrings();
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldCliente.setText(aux[0]);

                    } else {
                        textFieldCliente.requestFocus();
                        textFieldCliente.selectAll();
                    }
                }
            }
        });

        // Listeners
        btnFind.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoVenda.listInOrderNomeStrings();
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldId.setText(aux[0]);
                        clicarBotaoAutomaticamente(btnRetrieve, 0);
                    } else {
                        textFieldId.requestFocus();
                        textFieldNome.selectAll();
                    }
                }
            }
        });

        btnRetrieve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    venda = new Venda();
                    venda.setIdVenda(Integer.valueOf(textFieldId.getText()));

                    textFieldId.setText(textFieldId.getText().trim());//caso tenham sido digitados espaços
                    if (textFieldId.getText().equals("")) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para esse campo");
                        textFieldId.requestFocus();
                        textFieldId.selectAll();
                    } else {
                        venda = daoVenda.obter(venda.getIdVenda());
                        if (venda != null) { //se encontrou na lista
                            textFieldNome.setText(venda.getNomeVenda());
                            textFieldData.setText(sdf.format(venda.getDataVenda()));
                            textFieldCliente.setText(String.valueOf(venda.getClienteIdCliente().getIdCliente()));
                            atvBotoes(false, true, true, true);
                            habilitarAtributos(true, false, false, false, false);
                            labelAviso.setText("Encontrou - clic [Pesquisar], [Alterar] ou [Excluir]");
                            acao = "encontrou";
                        } else {
                            atvBotoes(true, true, false, false);
                            zerarAtributos();
                            labelAviso.setText("Não cadastrado - clic [Inserir] ou digite outra id [Pesquisar]");
                        }
                    }
                } catch (Exception e) {
                    labelAviso.setText("Erro na entrada de dados");
                }
            }
        });
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos();
                habilitarAtributos(false, true, true, true, true);
                textFieldNome.requestFocus();
                mostrarBotoes(false);
                labelAviso.setText("Preencha os campos e clic [Salvar] ou clic [Cancelar]");
                acao = "insert";
            }
        });
        btnSave.addActionListener(new ActionListener() {
            private String erro;

            @Override
            public void actionPerformed(ActionEvent ae) {
                this.erro = "";
                if (textFieldNome.getText().equals("")) {
                    JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para todos os campos");
                } else {

                    if (acao.equals("insert")) {
                        venda = new Venda();
                        venda.setIdVenda(Integer.valueOf(textFieldId.getText()));
                        venda.setNomeVenda(textFieldNome.getText());
                        try {
                            venda.setDataVenda(sdf.parse(textFieldData.getText()));
                        } catch (ParseException ex) {
                            Logger.getLogger(GUIProduto.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        cliente = daoCliente.obter(Integer.valueOf(textFieldCliente.getText()));
                        venda.setClienteIdCliente(cliente);
                        daoVenda.inserir(venda);
                        habilitarAtributos(true, false, false, false, false);
                        mostrarBotoes(true);
                        atvBotoes(false, true, false, false);
                        labelAviso.setText("Registro inserido...");
                    } else {  //acao = update
                        venda.setIdVenda(Integer.valueOf(textFieldId.getText()));
                        venda.setNomeVenda(textFieldNome.getText());
                        try {
                            venda.setDataVenda(sdf.parse(textFieldData.getText()));
                        } catch (ParseException ex) {
                            Logger.getLogger(GUIProduto.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        cliente = daoCliente.obter(Integer.valueOf(textFieldCliente.getText()));
                        venda.setClienteIdCliente(cliente);
                        daoVenda.atualizar(venda);
                        mostrarBotoes(true);
                        habilitarAtributos(true, false, false, false, false);
                        atvBotoes(false, true, false, false);

                    }
                }

            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos();
                atvBotoes(false, true, false, false);
                habilitarAtributos(true, false, false, false, false);
                mostrarBotoes(true);
            }
        });
        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "list";
                GUIListagemVenda guiListagem = new GUIListagemVenda(daoVenda.listInOrderNome(), getBounds().x, getBounds().y);
            }
        });
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "update";
                mostrarBotoes(false);
                habilitarAtributos(false, true, true, true, true);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(cp,
                        "Confirma a exclusão do registro <ID = " + venda.getIdVenda() + ">?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {
                    daoVenda.remover(venda);

                    zerarAtributos();
                    textFieldId.requestFocus();
                    textFieldId.selectAll();
                }
            }
        });
        textFieldId.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldId.setBackground(Color.GREEN);
                if (acao != "encontrou") {
                    labelAviso.setText("Digite uma id e clic [Pesquisar]");
                }
            }

            @Override
            public void focusLost(FocusEvent fe) {
                textFieldId.setBackground(Color.white);
            }
        });
        textFieldId.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldId.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldId.setBackground(Color.white);
            }
        });
        textFieldNome.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldNome.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldNome.setBackground(Color.white);
            }
        });

        textFieldCliente.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldCliente.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldCliente.setBackground(Color.white);
            }
        });

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //antes de sair do sistema, grava os dados da lista em disco
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        setModal(true);
        setVisible(true);
    }
}
