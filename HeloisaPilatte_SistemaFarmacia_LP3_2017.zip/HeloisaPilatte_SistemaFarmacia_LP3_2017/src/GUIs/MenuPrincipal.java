package GUIs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import tools.CentroDoMonitorMaior;

public class MenuPrincipal extends JFrame {

    Container cp;
    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JLabel lbTitulo = new JLabel("Farmácia Pilatte");

    Font fonte = new Font("Monotype Corsiva", Font.BOLD, 30);

    JLabel labelComImagemDeTamanhoDiferente = new JLabel();

    JMenuBar menuBar = new JMenuBar();
    JMenu menuCadastros = new JMenu("Cadastros");
    JMenuItem cadCliente = new JMenuItem("Cliente");
    JMenuItem cadVenda = new JMenuItem("Venda");
    JMenuItem cadProduto = new JMenuItem("Produto");
    JMenuItem cadCategoria = new JMenuItem("Categoria");
    
    JMenu menuCompor = new JMenu("Compra");
    JMenu menuLoc = new JMenu("Venha até nós");
    
    JMenuItem cadCompra = new JMenuItem("Compra");
    JMenuItem menuILoc = new JMenuItem("Localizacao");
    
 

    JMenu menuScreen = new JMenu("Posicionamento no monitor");
    JMenuItem posicaoNaJanela = new JMenuItem("Onde está...");
    Point p;

    public MenuPrincipal(Dimension dimensao) {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(dimensao);
        setTitle("Farmácia");

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        pnNorte.add(lbTitulo);
        lbTitulo.setFont(fonte);
        pnNorte.setBackground(Color.LIGHT_GRAY);

        //para ajustar o tamanho de uma imagem
        try {
            ImageIcon icone = new ImageIcon(getClass().getResource("/icones/farmaciaim.jpg"));
            Image imagemAux;
            imagemAux = icone.getImage();
            icone.setImage(imagemAux.getScaledInstance(660, 315, Image.SCALE_FAST));

            labelComImagemDeTamanhoDiferente = new JLabel();
            labelComImagemDeTamanhoDiferente.setIcon(icone);
        } catch (Exception e) {
            System.out.println("erro ao carregar a imagem");
        }

        pnCentro.add(labelComImagemDeTamanhoDiferente);
        pnCentro.setBackground(Color.BLACK);

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);

        setJMenuBar(menuBar);
        menuBar.add(menuCadastros);

        menuCadastros.add(cadCliente);
        menuCadastros.add(cadVenda);
        menuCadastros.add(cadProduto);
        menuCadastros.add(cadCategoria);

        menuBar.add(menuCompor);
        
        menuBar.add(menuLoc);
        menuLoc.add(menuILoc);
        menuCompor.add(cadCompra);
      
        
        
        menuScreen.setVisible(false); //mostrar se precisar ajustar a posicao na tela
        menuBar.add(menuScreen);

        menuScreen.add(posicaoNaJanela);
        
        menuILoc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.google.com.br/maps/dir//-24.0392522,-52.3726715/@-24.0406839,-52.3776752,17z"));
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        });
        
        cadCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICliente gcliente = new GUICliente();
            }
        });
        cadVenda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIVenda gvenda = new GUIVenda(p);
            }
        });
         
        cadProduto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIProduto guiProduto = new GUIProduto(p);
            }
        });
        cadCategoria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICategoria gcategoria = new GUICategoria(p);
            }
        });
        
        cadCompra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICompra gcompra = new GUICompra(p);
            }
        });

      
       
        posicaoNaJanela.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("X " + getBounds().x);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai do sistema  
                System.exit(0);
            }
        });

        
        pack();
        p = new CentroDoMonitorMaior().getCentroMonitorMaior(this);
        setLocation(p);
        setVisible(true);
    }
}
