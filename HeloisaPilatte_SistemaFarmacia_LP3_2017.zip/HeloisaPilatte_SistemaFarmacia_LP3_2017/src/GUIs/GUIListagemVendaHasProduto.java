package GUIs;

import Entidades.Produto;
import Entidades.VendaHasProduto;
import daos.DAOVendaHasProduto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class GUIListagemVendaHasProduto extends JDialog {

    JPanel painelTa = new JPanel();
    JPanel painelPAGAR = new JPanel();
    
    JButton btnFinalizar = new JButton("FINALIZAR");
    JLabel labelAviso = new JLabel("");
   
    DAOVendaHasProduto daoVendaHasProduto = new DAOVendaHasProduto();
    VendaHasProduto vendaHasProduto;

   

    public GUIListagemVendaHasProduto(int idvenda, VendaHasProduto x ) {
        setTitle("Listagem");
        setSize(500, 180);//tamanho da janela
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);//libera ao sair (tira da memória a classe
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        setModal(true);
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

       

        String[] colunas = {"IdProduto", "Preco", "Quantidade", "Total"};
        List<VendaHasProduto> lista = daoVendaHasProduto.listByIdVenda(idvenda);
        
        int lin = lista.size();
        String[][] dadosCompra;
        double cont = 0;

        if (lin > 0) {
            dadosCompra = new String[lin][colunas.length];
            for (int i = 0; i < lin; i++) {
                dadosCompra[i][0] = String.valueOf(lista.get(i).getVendaHasProdutoPK().getProdutoIdProduto());
                
                dadosCompra[i][1] = String.valueOf(lista.get(i).getPrecounitVenda());
                dadosCompra[i][2] = String.valueOf(lista.get(i).getQuantidadeVenda());
                double valort = lista.get(i).getPrecounitVenda() * lista.get(i).getQuantidadeVenda();
                dadosCompra[i][3] = String.valueOf(valort);
                cont += valort;

            }
        } else {
            dadosCompra = new String[1][colunas.length];
        }
        
        DefaultTableModel modelo = new DefaultTableModel() {
            public boolean isCellEditable(int linha, int coluna) {
                return false;

            }
        };

        modelo.setDataVector(dadosCompra, colunas);
        JTable tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);

        JPanel painel = new JPanel();
        painel.add(scroll);

        JPanel painel2 = new JPanel();
        JLabel compra = new JLabel("Valor Total da Compra: " + cont);
        painel2.add(compra);
        painel2.add(btnFinalizar);
        
        
        cp.add(painel, BorderLayout.CENTER);
        cp.add(painel2, BorderLayout.SOUTH);
        
       
        
        btnFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                     List<VendaHasProduto> listax = daoVendaHasProduto.listByIdVenda(x.getVendaHasProdutoPK().getVendaIdVenda());
                double cont = 0;
                for (int i = 0; i < listax.size(); i++) {
                    cont += listax.get(i).getPrecounitVenda() * listax.get(i).getQuantidadeVenda();

                }
                int selectedOption = JOptionPane.showOptionDialog(null, "O valor total é R$"+cont+" deseja finalizar?", "JoptionPane", JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.INFORMATION_MESSAGE, null, new String[]{"Sim", "Não"}, "default");
                
                if (selectedOption == JOptionPane.YES_OPTION) {
                 int selectedOption1 = JOptionPane.showOptionDialog(null, "Parcelado ou a vista?", "JoptionPane", JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.INFORMATION_MESSAGE, null, new String[]{"Parcelado", "A vista"}, "default");

                    if (selectedOption1 == JOptionPane.YES_OPTION) {
                         int selectedOption2 = JOptionPane.showOptionDialog(null, "2x ou 4x?", "JoptionPane", JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.INFORMATION_MESSAGE, null, new String[]{"2x", "4x"}, "default");
                        
                         if (selectedOption2 == JOptionPane.YES_OPTION) {
                         JOptionPane.showMessageDialog(null, "O valor de cada parcela é R$"+(cont/2));
                         JOptionPane.showMessageDialog(null, "Obrigada por comprar conosco");
                         
                         }else{
                         JOptionPane.showMessageDialog(null, "O valor de cada parcela é R$"+(cont/4));
                         JOptionPane.showMessageDialog(null, "Obrigada por comprar conosco");
                         
                         }}else{
                         JOptionPane.showMessageDialog(null, "O valor total é "+(cont));
                         JOptionPane.showMessageDialog(null, "Obrigada por comprar conosco");
                    }
                
                }else{
                labelAviso.setText("Compra cancelada");}
            }
        });
        
        setVisible(true);//faz a janela ficar visível    
        
    }
}
