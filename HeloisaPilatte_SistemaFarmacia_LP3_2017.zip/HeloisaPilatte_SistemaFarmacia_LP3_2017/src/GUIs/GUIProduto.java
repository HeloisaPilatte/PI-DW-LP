package GUIs;

import daos.DAOProduto;
import daos.DAOCategoria;
import Entidades.Produto;
import Entidades.Categoria;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import tools.CentroDoMonitorMaior;
import tools.CopiaImagem;
import tools.JanelaPesquisar;
import tools.MyJOptionPane;

public class GUIProduto extends JDialog {

    ImageIcon iconeCreate = new ImageIcon(getClass().getResource("/icones/create.png"));
    ImageIcon iconeRetrieve = new ImageIcon(getClass().getResource("/icones/retrieve.png"));
    ImageIcon iconeUpdate = new ImageIcon(getClass().getResource("/icones/update.png"));
    ImageIcon iconeDelete = new ImageIcon(getClass().getResource("/icones/delete.png"));
    ImageIcon iconeSave = new ImageIcon(getClass().getResource("/icones/save.png"));
    ImageIcon iconeCancel = new ImageIcon(getClass().getResource("/icones/cancel.png"));
    ImageIcon iconeListar = new ImageIcon(getClass().getResource("/icones/list.png"));
    private ImageIcon iconeFind = new ImageIcon(getClass().getResource("/icones/findCheck.png"));
    private ImageIcon iconeFindPequeno = new ImageIcon(getClass().getResource("/icones/find.png"));

    private JButton btnFind = new JButton(iconeFind);
    JButton btnCreate = new JButton(iconeCreate);
    JButton btnRetrieve = new JButton(iconeRetrieve);
    JButton btnUpdate = new JButton(iconeUpdate);
    JButton btnDelete = new JButton(iconeDelete);
    JButton btnSave = new JButton(iconeSave);
    JButton btnCancel = new JButton(iconeCancel);
    JButton btnList = new JButton(iconeListar);
    JLabel labelid = new JLabel("Id");
    JTextField textFieldid = new JTextField(50);
    JLabel labelNomeProduto = new JLabel("Nome produto");
    JTextField textFieldNomeProduto = new JTextField(250);
    JLabel labelPreco = new JLabel("Preco");
    JTextField textFieldPreco = new JTextField(50);
    JLabel labelEstoque = new JLabel("Estoque");
    JTextField textFieldEstoque = new JTextField(50);
    JLabel lData = new JLabel("Data: -> dd/MM/yyyy ");
    DateTextField tfData = new DateTextField();

    JLabel labelCategoria_Id = new JLabel("Categoria");

    JPanel pnCategoria = new JPanel();
    JTextField textFieldCategoria = new JTextField(5);
    JButton btnC = new JButton(iconeFindPequeno);
    JLabel labelFoto = new JLabel(" ");
    JPanel aviso = new JPanel();
    JLabel labelAviso = new JLabel("");
    String acao = "";

    Image imagemAux;
    String origem;
    String destino = "src/fotos/";
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    DAOProduto daoProduto = new DAOProduto();
    Produto produto;
    DAOCategoria daoCategoria = new DAOCategoria();
    Categoria categoria = new Categoria();

    //para avisar caso não estejam cadastradas as unidades de medida
    List<String> listaC = daoCategoria.listStrings();

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    private void atvBotoes(boolean c, boolean r, boolean u, boolean d) {
        btnCreate.setEnabled(c);
        btnFind.setEnabled(r);
        btnRetrieve.setEnabled(r);
        btnUpdate.setEnabled(u);
        btnDelete.setEnabled(d);
        btnList.setEnabled(r);
    }

    public void mostrarBotoes(boolean visivel) {
        btnCreate.setVisible(visivel);
        btnRetrieve.setVisible(visivel);
        btnUpdate.setVisible(visivel);
        btnDelete.setVisible(visivel);
        btnList.setVisible(visivel);
        btnSave.setVisible(!visivel);
        btnCancel.setVisible(!visivel);
        btnFind.setVisible(visivel);
    }

    private void habilitarAtributos(boolean id_contato, boolean endereco, boolean celular, boolean email, boolean facebook, boolean cliente_id_cliente, boolean btnFindCli) {
        if (id_contato) {
            textFieldid.requestFocus();
            textFieldid.selectAll();
        }
        textFieldid.setEnabled(id_contato);
        textFieldid.setEditable(id_contato);
        textFieldNomeProduto.setEditable(endereco);
        textFieldPreco.setEditable(celular);
        textFieldEstoque.setEditable(email);
        tfData.setEditable(facebook);
        textFieldCategoria.setEditable(cliente_id_cliente);
        btnC.setVisible(btnFindCli);
    }

    public void zerarAtributos(int img) {
        textFieldNomeProduto.setText("");
        textFieldPreco.setText("");
        textFieldEstoque.setText("");
        textFieldCategoria.setText("");
        tfData.setText("");
        if (img == 0) {
            origem = "/fotos/0.png";
        } else {
            origem = "/fotos/0a.png";
        }
        ImageIcon icone = new ImageIcon(getClass().getResource(origem));

        imagemAux = icone.getImage();
        icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
        labelFoto.setIcon(icone);

    }

    public GUIProduto(Point p) {

        setTitle("Cadastro Produto");
        setSize(800, 500);//tamanho da janela
        //Point p = new CentroDoMonitorMaior().getCentroMonitorMaior(this);
        setLocation(p);
        Dimension dimensao = getSize();
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

        atvBotoes(false, true, false, false);
        habilitarAtributos(true, false, false, false, false, false, false);
        DateTextField data = new DateTextField();
        btnCreate.setToolTipText("Inserir novo registro");
        btnRetrieve.setToolTipText("Pesquisar por chave");
        btnFind.setToolTipText("Pesquisar em lista");
        btnUpdate.setToolTipText("Alterar");
        btnDelete.setToolTipText("Excluir");
        btnList.setToolTipText("Listar todos");
        btnSave.setToolTipText("Salvar");
        btnCancel.setToolTipText("Cancelar");
        JToolBar Toolbar1 = new JToolBar();
        Toolbar1.add(labelid);
        Toolbar1.add(textFieldid);
        Toolbar1.add(btnFind);
        Toolbar1.add(btnRetrieve);
        Toolbar1.add(btnCreate);
        Toolbar1.add(btnUpdate);
        Toolbar1.add(btnDelete);
        Toolbar1.add(btnSave);
        Toolbar1.add(btnCancel);
        Toolbar1.add(btnList);

        btnSave.setVisible(false);
        btnCancel.setVisible(false);

        JPanel painelCentro = new JPanel(new BorderLayout());
        JPanel centroDireita = new JPanel(new GridLayout(1, 1));
        JPanel centroEsquerda = new JPanel();
        centroDireita.add(labelFoto);

        pnCategoria.setLayout(new GridLayout(1, 2));
        pnCategoria.add(textFieldCategoria);
        pnCategoria.add(btnC);

        painelCentro.add(centroEsquerda, BorderLayout.CENTER);//painel dos atributos texto
        painelCentro.add(centroDireita, BorderLayout.EAST);

        centroEsquerda.setLayout(new GridLayout(8, 2));
        centroEsquerda.add(labelid);
        centroEsquerda.add(textFieldid);
        centroEsquerda.add(labelNomeProduto);
        centroEsquerda.add(textFieldNomeProduto);
        centroEsquerda.add(labelPreco);
        centroEsquerda.add(textFieldPreco);
        centroEsquerda.add(labelEstoque);
        centroEsquerda.add(textFieldEstoque);
        centroEsquerda.add(labelCategoria_Id);
        centroEsquerda.add(pnCategoria);
        centroEsquerda.add(lData);
        centroEsquerda.add(tfData);

        aviso.add(labelAviso);
        aviso.setBackground(Color.yellow);
        cp.add(Toolbar1, BorderLayout.NORTH);
        cp.add(painelCentro, BorderLayout.CENTER);
        cp.add(aviso, BorderLayout.SOUTH);
        textFieldid.requestFocus();
        textFieldid.selectAll();
        textFieldid.setBackground(Color.GREEN);
        labelAviso.setText("Digite uma id e clic [Pesquisar]");

        //para ajustar o tamanho de uma imagem
        try {
            origem = "/fotos/0.png";
            ImageIcon icone = new ImageIcon(getClass().getResource(origem));
            imagemAux = icone.getImage();
            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
            labelFoto.setIcon(icone);

        } catch (Exception e) {
            System.out.println("erro ao carregar a imagem");
        }

        if (listaC.size() == 0) {
            JOptionPane.showMessageDialog(cp, "Não é possível cadastrar produtos sem \ncadastrar primeiro as Categorias \n"
                    + "Escolha menu Cadastros->Categoria");
            return;

        }

//        setVisible(true);//faz a janela ficar visível
        // Listeners
        btnC.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                List<String> listaAuxiliar = daoCategoria.listStrings();
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldCategoria.setText(aux[0]);

                    } else {
                        textFieldCategoria.requestFocus();
                        textFieldCategoria.selectAll();
                    }
                }
            }
        });

        btnFind.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoProduto.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldid.setText(aux[0]);
                        clicarBotaoAutomaticamente(btnRetrieve, 0);
                    } else {
                        textFieldid.requestFocus();
                        textFieldNomeProduto.selectAll();
                    }
                }
            }
        });

        btnRetrieve.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent ae) {

                try {
                    produto = new Produto();
                    produto.setIdProduto(Integer.valueOf(textFieldid.getText()));
                    textFieldid.setText(textFieldid.getText().trim());//caso tenham sido digitados espaços

                    if (textFieldid.getText().equals("")) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para esse campo");
                        textFieldid.requestFocus();
                        textFieldid.selectAll();
                    } else {
                        produto = daoProduto.obter(produto.getIdProduto());
                        if (produto != null) { //se encontrou na lista
                            textFieldNomeProduto.setText(produto.getNomeProduto());
                            textFieldPreco.setText(String.valueOf(produto.getPrecoProduto()));
                            textFieldEstoque.setText(String.valueOf(produto.getEstoqueProduto()));
                            textFieldCategoria.setText(String.valueOf(produto.getCategoriaIdCategoria().getIdCategoria()));
                            tfData.setText(sdf.format(produto.getDataProduto()));
                            atvBotoes(false, true, true, true);
                            habilitarAtributos(true, false, false, false, false, false, false);
                            labelAviso.setText("Encontrou - clic [Pesquisar], [Alterar] ou [Excluir]");
                            acao = "encontrou";

                            try {
                                String aux = String.valueOf(produto.getIdProduto()).trim();
                                origem = "/fotos/" + aux + ".png";
                                ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                                imagemAux = icone.getImage();
                                icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));

                                labelFoto.setIcon(icone);

                            } catch (Exception e) {
                                System.out.println("nao achou " + origem);
                                origem = "/fotos/0.png";
                                ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                                imagemAux = icone.getImage();
                                icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
                                labelFoto.setIcon(icone);
                            }

                        } else {
                            atvBotoes(true, true, false, false);
                            zerarAtributos(0);
                            labelAviso.setText("Não cadastrado - clic [Inserir] ou digite outra id [Pesquisar]");
                        }
                    }
                } catch (Exception e) {
                    labelAviso.setText("Erro na entrada de dados");
                }
            }
        });
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos(1);
                habilitarAtributos(false, true, true, true, true, true, true);
                textFieldNomeProduto.requestFocus();
                mostrarBotoes(false);
                labelAviso.setText("Preencha os campos e clic [Salvar] ou clic [Cancelar]");
                acao = "insert";
            }
        });
        btnSave.addActionListener(new ActionListener() {
            private String erro;

            private int p;

            @Override
            public void actionPerformed(ActionEvent ae) {
                this.erro = "";
                if (textFieldPreco.getText().equals("") || textFieldEstoque.getText().equals("") || textFieldNomeProduto.getText().equals("")) {
                    JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para todos os campos!");

                } else {
                    try {
                        this.p = Integer.valueOf(textFieldPreco.getText());
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um inteiro para o campo |Preco|");
                        this.erro = "ta errado";
                    }
                    try {
                        this.p = Integer.valueOf(textFieldEstoque.getText());
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um inteiro para o campo |Estoque|");
                        this.erro = "ta errado";
                    }

                    if (this.erro.equals("") && acao.equals("insert")) {
                        produto = new Produto();
                        produto.setIdProduto(Integer.valueOf(textFieldid.getText()));
                        produto.setNomeProduto(textFieldNomeProduto.getText());
                        produto.setPrecoProduto(Integer.valueOf(textFieldPreco.getText()));
                        produto.setEstoqueProduto(Integer.valueOf(textFieldEstoque.getText()));
                        try {
                            produto.setDataProduto(sdf.parse(tfData.getText()));
                        } catch (ParseException ex) {
                            Logger.getLogger(GUIProduto.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        categoria = daoCategoria.obter(Integer.valueOf(textFieldCategoria.getText()));
                        produto.setCategoriaIdCategoria(categoria);
                        try {
                            produto.setDataProduto(sdf.parse(tfData.getText()));
                        } catch (ParseException ex) {
                            Logger.getLogger(GUIProduto.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        destino = destino + produto.getIdProduto() + ".png";
//                    System.out.println("origem =>" + origem);
//                    System.out.println("destino =>" + destino);
                        CopiaImagem.copiar(origem, destino);
                        destino = "src/fotos/";
                        daoProduto.inserir(produto);
                        habilitarAtributos(true, false, false, false, false, false, false);
                        mostrarBotoes(true);
                        atvBotoes(false, true, false, false);
                        labelAviso.setText("Registro inserido...");
                    } else {

                        if (this.erro.equals("")) {
                            produto.setIdProduto(Integer.valueOf(textFieldid.getText()));
                            produto.setNomeProduto(textFieldNomeProduto.getText());
                            produto.setPrecoProduto(Integer.valueOf(textFieldPreco.getText()));
                            produto.setEstoqueProduto(Integer.valueOf(textFieldEstoque.getText()));

                            categoria = daoCategoria.obter(Integer.valueOf(textFieldCategoria.getText()));
                            produto.setCategoriaIdCategoria(categoria);
                            try {
                                produto.setDataProduto(sdf.parse(tfData.getText()));
                            } catch (ParseException ex) {
                                Logger.getLogger(GUIProduto.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            destino = destino + produto.getIdProduto() + ".png";
//                    System.out.println("origem =>" + origem);
//                    System.out.println("destino =>" + destino);
                            CopiaImagem.copiar(origem, destino);
                            destino = "src/fotos/";
                            daoProduto.atualizar(produto);
                            mostrarBotoes(true);
                            habilitarAtributos(true, false, false, false, false, false, false);
                            atvBotoes(false, true, false, false);

                        }

                    }
                }
            }
        });
        labelFoto.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (acao.equals("insert") || acao.equals("update")) {
                    JFileChooser fc = new JFileChooser();
                    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    if (fc.showOpenDialog(cp) == JFileChooser.APPROVE_OPTION) {
                        File img = fc.getSelectedFile();
                        origem = fc.getSelectedFile().getAbsolutePath();
                        try {
                            ImageIcon icone = new javax.swing.ImageIcon(img.getAbsolutePath());
                            Image imagemAux;
                            imagemAux = icone.getImage();
                            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
                            labelFoto.setIcon(icone);

                        } catch (Exception ex) {
                            System.out.println("Erro: " + ex.getMessage());
                        }
                    }

                }

            }
        });

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos(0);
                atvBotoes(false, true, false, false);
                habilitarAtributos(true, false, false, false, false, false, false);
                mostrarBotoes(true);
            }
        });
        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "list";
                GUIListagemProduto guiListagem = new GUIListagemProduto(daoProduto.listInOrderNome(), getBounds().x, getBounds().y);
            }
        });
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "update";
                mostrarBotoes(false);
                habilitarAtributos(false, true, true, true, true, true, true);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (new MyJOptionPane(new Point(p.x + dimensao.width / 2, p.y + dimensao.height / 2), "Excluir?").getValorRetornado()) {

                    String aux = String.valueOf(produto.getIdProduto()).trim();
                    origem = "src/fotos/" + aux + ".png";
                    // System.out.println(origem);
                    try {
                        File f = new File(origem);
                        if (f.exists()) {
                            f.delete();
                        }
                    } catch (Exception e) {
                        System.out.println("foto não deletada");
                    }

                    daoProduto.remover(produto);
                    labelAviso.setText("");
                    zerarAtributos(0);
                    textFieldid.requestFocus();
                    textFieldid.selectAll();
                } else {
                    labelAviso.setText("Exclusão cancelada");
                    textFieldid.requestFocus();
                    textFieldid.selectAll();
                }

            }
        });

        textFieldid.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldid.setBackground(Color.GREEN);
                if (acao != "encontrou") {
                    labelAviso.setText("Digite uma id e clic [Pesquisar]");
                }
            }

            @Override
            public void focusLost(FocusEvent fe) {
                textFieldid.setBackground(Color.white);
            }
        });
        textFieldid.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldid.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldid.setBackground(Color.white);
            }
        });
        textFieldNomeProduto.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldNomeProduto.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldNomeProduto.setBackground(Color.white);
            }
        });
        textFieldPreco.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldPreco.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldPreco.setBackground(Color.white);
            }
        });

        textFieldEstoque.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldEstoque.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldEstoque.setBackground(Color.white);
            }
        });

        textFieldCategoria.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldCategoria.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldCategoria.setBackground(Color.white);
            }
        });

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //antes de sair do sistema, grava os dados da lista em disco
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setModal(true);
        setVisible(true);
    }
}
