package GUIs;

import Entidades.VendaHasProduto;
import Entidades.VendaHasProdutoPK;
import daos.DAOVendaHasProduto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showInputDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import tools.JanelaPesquisar;
import tools.MyJOptionPane;

public class GUICompra extends JDialog {

    ImageIcon iconeCreate = new ImageIcon(getClass().getResource("/icones/create.png"));
    ImageIcon iconeRetrieve = new ImageIcon(getClass().getResource("/icones/retrieve.png"));
    ImageIcon iconeUpdate = new ImageIcon(getClass().getResource("/icones/update.png"));
    ImageIcon iconeDelete = new ImageIcon(getClass().getResource("/icones/delete.png"));
    ImageIcon iconeSave = new ImageIcon(getClass().getResource("/icones/save.png"));
    ImageIcon iconeCancel = new ImageIcon(getClass().getResource("/icones/cancel.png"));
    ImageIcon iconeListar = new ImageIcon(GetImg("src/icones/carrinhoDeCompras.png", 30, 30));
    ImageIcon iconeFinalizar = new ImageIcon(GetImg("src/icones/dinheiro.png", 30, 30));

    private ImageIcon iconeFind = new ImageIcon(getClass().getResource("/icones/findCheck.png"));
    private ImageIcon iconeFindPequeno = new ImageIcon(getClass().getResource("/icones/find.png"));

    public Image GetImg(String origem, int x, int y) {
        ImageIcon imgIcone = new ImageIcon(origem);

        Image iIcone = imgIcone.getImage();
        Image Icone = iIcone.getScaledInstance(x, y, java.awt.Image.SCALE_SMOOTH);
        return Icone;
    }

    private JButton btnFind = new JButton(iconeFind);
    JButton btnCreate = new JButton(iconeCreate);
    JButton btnRetrieve = new JButton(iconeRetrieve);
    JButton btnUpdate = new JButton(iconeUpdate);
    JButton btnDelete = new JButton(iconeDelete);
    JButton btnSave = new JButton(iconeSave);
    JButton btnCancel = new JButton(iconeCancel);
    JButton btnList = new JButton(iconeListar);
    JButton btnFinalizar = new JButton(iconeFinalizar);

    JLabel labelVenda = new JLabel("Venda");
    JTextField textFieldVenda = new JTextField(250);
    JLabel labelProduto = new JLabel("Produto");
    JTextField textFieldProduto = new JTextField(50);
    JLabel labelQuantidade = new JLabel("Quantidade ");
    JTextField textFieldQuantidade = new JTextField(50);
    JLabel labelPrecoUnit = new JLabel("Preco Unit. ");
    JTextField textFieldPrecoUnit = new JTextField(50);

    JPanel aviso = new JPanel();
    JLabel labelAviso = new JLabel("");
    String acao = "";

    DAOVendaHasProduto daoVendaHasProduto = new DAOVendaHasProduto();
    VendaHasProduto vendaHasProduto;

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    private void atvBotoes(boolean c, boolean r, boolean u, boolean d) {
        btnCreate.setEnabled(c);
        btnFind.setEnabled(r);
        btnRetrieve.setEnabled(r);
        btnUpdate.setEnabled(u);
        btnDelete.setEnabled(d);
        btnList.setEnabled(r);
        btnFinalizar.setEnabled(r);
    }

    public void mostrarBotoes(boolean visivel) {
        btnCreate.setVisible(visivel);
        btnRetrieve.setVisible(visivel);
        btnUpdate.setVisible(visivel);
        btnDelete.setVisible(visivel);
        btnList.setVisible(visivel);
        btnSave.setVisible(!visivel);
        btnCancel.setVisible(!visivel);
        btnFind.setVisible(visivel);
        btnFinalizar.setVisible(visivel);
    }

    private void habilitarAtributos(boolean id_contato, boolean telefone, boolean email, boolean facebook) {

        textFieldVenda.setEditable(id_contato);
        textFieldProduto.setEditable(telefone);
        textFieldQuantidade.setEditable(email);
        textFieldPrecoUnit.setEditable(facebook);

    }

    public void zerarAtributos() {

        textFieldQuantidade.setText("");
        textFieldPrecoUnit.setText("");

    }
    public GUICompra(){
    
    }

    public GUICompra(Point p) {

        setTitle("Cadastro Compra");
        setSize(500, 300);//tamanho da janela
        setLocation(p);
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

        atvBotoes(false, true, false, false);
        habilitarAtributos(true, true, false, false);
        btnCreate.setToolTipText("Inserir novo registro");
        btnRetrieve.setToolTipText("Pesquisar por chave");
        btnFind.setToolTipText("Pesquisar em lista");
        btnUpdate.setToolTipText("Alterar");
        btnDelete.setToolTipText("Excluir");
        btnList.setToolTipText("Listar todos");
        btnFinalizar.setToolTipText("Finalizar Compra");

        btnSave.setToolTipText("Salvar");
        btnCancel.setToolTipText("Cancelar");
        JToolBar Toolbar1 = new JToolBar();

        Toolbar1.add(btnFind);
        Toolbar1.add(btnRetrieve);
        Toolbar1.add(btnCreate);
        Toolbar1.add(btnUpdate);
        Toolbar1.add(btnDelete);
        Toolbar1.add(btnSave);
        Toolbar1.add(btnCancel);
        Toolbar1.add(btnList);
        //Toolbar1.add(btnFinalizar);

        btnSave.setVisible(false);
        btnCancel.setVisible(false);

        JPanel centro = new JPanel();
        centro.setLayout(new GridLayout(4, 2));

        centro.add(labelVenda);
        centro.add(textFieldVenda);
        centro.add(labelProduto);
        centro.add(textFieldProduto);
        centro.add(labelQuantidade);
        centro.add(textFieldQuantidade);
        centro.add(labelPrecoUnit);
        centro.add(textFieldPrecoUnit);

        aviso.add(labelAviso);
        aviso.setBackground(Color.yellow);
        cp.add(Toolbar1, BorderLayout.NORTH);
        cp.add(centro, BorderLayout.CENTER);
        cp.add(aviso, BorderLayout.SOUTH);

        labelAviso.setText("");

        btnFind.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoVendaHasProduto.listStrings();
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x - getWidth() / 2 + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split(" - ");
                        textFieldVenda.setText(aux[0]);
                        textFieldProduto.setText(aux[1]);
                        clicarBotaoAutomaticamente(btnRetrieve, 0);
                    }
                }
            }
        });

        btnRetrieve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    if (textFieldVenda.getText().equals("") || textFieldProduto.getText().equals("")) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para esse campo");

                    } else {

                        VendaHasProdutoPK vendaHasProdutoPK = new VendaHasProdutoPK(Integer.valueOf(textFieldVenda.getText()), Integer.valueOf(textFieldProduto.getText()));
                        vendaHasProduto = daoVendaHasProduto.obter(vendaHasProdutoPK);

                        if (vendaHasProduto != null) { //se encontrou na lista
                            textFieldQuantidade.setText(String.valueOf(vendaHasProduto.getQuantidadeVenda()));
                            textFieldPrecoUnit.setText(String.valueOf(vendaHasProduto.getPrecounitVenda()));
                            atvBotoes(false, true, true, true);
                            habilitarAtributos(true, true, false, false);
                            labelAviso.setText("Encontrou - clic [Pesquisar], [Alterar] ou [Excluir]");
                            acao = "encontrou";

                        } else {
                            atvBotoes(true, true, false, false);
                            zerarAtributos();
                            labelAviso.setText("Não cadastrado - clic [Inserir] ou digite outra id [Pesquisar]");
                        }
                    }
                } catch (Exception e) {
                    labelAviso.setText("Erro na entrada de dados");
                }
            }
        });
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos();
                habilitarAtributos(false, false, true, true);
                textFieldQuantidade.requestFocus();
                mostrarBotoes(false);
                labelAviso.setText("Preencha os campos e clic [Salvar] ou clic [Cancelar]");
                acao = "insert";
            }
        });

        btnSave.addActionListener(new ActionListener() {
            private String erro;

            @Override

            public void actionPerformed(ActionEvent ae) {
                this.erro = "";
                try {

                    VendaHasProdutoPK vendaHasProdutoPK = new VendaHasProdutoPK(Integer.valueOf(textFieldVenda.getText()), Integer.valueOf(textFieldProduto.getText()));

                    vendaHasProduto = new VendaHasProduto(vendaHasProdutoPK);

                    vendaHasProduto.setQuantidadeVenda(Integer.valueOf(textFieldQuantidade.getText()));
                    vendaHasProduto.setPrecounitVenda(Double.valueOf(textFieldPrecoUnit.getText()));

                    if (acao.equals("insert")) {

                        daoVendaHasProduto.inserir(vendaHasProduto);

                        labelAviso.setText("Registro inserido...");

                    } else {  //acao = update
                        daoVendaHasProduto.atualizar(vendaHasProduto);
                        labelAviso.setText("atualizado");

                    }
                    mostrarBotoes(true);
                    habilitarAtributos(true, true, false, false);
                    atvBotoes(false, true, false, false);

                } catch (Exception x) {
                    JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para todos os campos!");

                }
            }
        });

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos();
                atvBotoes(false, true, false, false);
                habilitarAtributos(true, true, false, false);
                mostrarBotoes(true);
            }
        });

        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "list";
                GUIListagemVendaHasProduto guiListagem = new GUIListagemVendaHasProduto(vendaHasProduto.getVendaHasProdutoPK().getVendaIdVenda(),vendaHasProduto);
            }
        });

        btnFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
            }
        });
        
      

        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "update";
                mostrarBotoes(false);
                habilitarAtributos(false, false, true, true);
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (new MyJOptionPane(getLocation(), "Excluir?").getValorRetornado()) {

                    daoVendaHasProduto.remover(vendaHasProduto);
                    labelAviso.setText("");
                    zerarAtributos();
                } else {
                    labelAviso.setText("Exclusão cancelada");

                }
            }
        });

        textFieldVenda.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                textFieldVenda.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent e) {
                textFieldVenda.setBackground(Color.WHITE);
            }
        });

        textFieldProduto.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                textFieldProduto.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent e) {
                textFieldProduto.setBackground(Color.WHITE);
            }
        });

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //antes de sair do sistema, grava os dados da lista em disco

        addWindowListener(
                new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setModal(true);
        setVisible(true);
    }
    
    public void top(){
        btnFinalizar.doClick();
    }
}
