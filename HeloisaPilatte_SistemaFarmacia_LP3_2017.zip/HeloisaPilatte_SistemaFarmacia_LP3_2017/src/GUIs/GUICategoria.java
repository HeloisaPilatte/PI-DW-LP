package GUIs;

import daos.DAOCategoria;
import Entidades.Categoria;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import tools.JanelaPesquisar;

public class GUICategoria extends JDialog {

    ImageIcon iconeCreate = new ImageIcon(getClass().getResource("/icones/create.png"));
    ImageIcon iconeRetrieve = new ImageIcon(getClass().getResource("/icones/retrieve.png"));
    ImageIcon iconeUpdate = new ImageIcon(getClass().getResource("/icones/update.png"));
    ImageIcon iconeDelete = new ImageIcon(getClass().getResource("/icones/delete.png"));
    ImageIcon iconeSave = new ImageIcon(getClass().getResource("/icones/save.png"));
    ImageIcon iconeCancel = new ImageIcon(getClass().getResource("/icones/cancel.png"));
    ImageIcon iconeListar = new ImageIcon(getClass().getResource("/icones/list.png"));
    ImageIcon iconeFind = new ImageIcon(getClass().getResource("/icones/findCheck.png"));

    JButton btnFind = new JButton(iconeFind);
    JButton btnCreate = new JButton(iconeCreate);
    JButton btnRetrieve = new JButton(iconeRetrieve);
    JButton btnUpdate = new JButton(iconeUpdate);
    JButton btnDelete = new JButton(iconeDelete);
    JButton btnSave = new JButton(iconeSave);
    JButton btnCancel = new JButton(iconeCancel);
    JButton btnList = new JButton(iconeListar);
    JLabel labelIdCategoria = new JLabel("Id");
    JTextField textFieldIdCategoria = new JTextField(10);
    JLabel labelNomeCategoria = new JLabel("Nome");
    JTextField textFieldNomeCategoria = new JTextField(20);
    JPanel aviso = new JPanel();
    JLabel labelAviso = new JLabel("");
    String acao = "";//variavel para facilitar insert e update
    DAOCategoria daoCategoria = new DAOCategoria();
    Categoria categoria;

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    private void atvBotoes(boolean c, boolean r, boolean u, boolean d) {
        btnCreate.setEnabled(c);
        btnRetrieve.setEnabled(r);
        btnUpdate.setEnabled(u);
        btnDelete.setEnabled(d);
        btnList.setEnabled(r);
    }

    public void mostrarBotoes(boolean visivel) {
        btnCreate.setVisible(visivel);
        btnRetrieve.setVisible(visivel);
        btnUpdate.setVisible(visivel);
        btnDelete.setVisible(visivel);
        btnList.setVisible(visivel);
        btnSave.setVisible(!visivel);
        btnCancel.setVisible(!visivel);
        btnFind.setVisible(visivel);
    }

    private void habilitarAtributos(boolean id_cartao, boolean numero_cartao) {
        if (id_cartao) {
            textFieldIdCategoria.requestFocus();
            textFieldIdCategoria.selectAll();
        }
        textFieldIdCategoria.setEnabled(id_cartao);
        textFieldIdCategoria.setEditable(id_cartao);
        textFieldNomeCategoria.setEditable(numero_cartao);
    }

    public void zerarAtributos() {
        textFieldNomeCategoria.setText("");
        textFieldIdCategoria.setText("");
    }

    public GUICategoria(Point p) {
        setTitle("Cadastro de categoria");
        setLocationRelativeTo(null);
        setLocation(p);

        setSize(500, 300);//tamanho da janela
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

        atvBotoes(false, true, false, false);
        habilitarAtributos(true, false);
        btnCreate.setToolTipText("Inserir novo registro");
        btnRetrieve.setToolTipText("Pesquisar por chave");
        btnUpdate.setToolTipText("Alterar");
        btnDelete.setToolTipText("Excluir");
        btnList.setToolTipText("Listar todos");
        btnSave.setToolTipText("Salvar");
        btnCancel.setToolTipText("Cancelar");
        JToolBar Toolbar1 = new JToolBar();
        Toolbar1.add(labelIdCategoria);
        Toolbar1.add(textFieldIdCategoria);
        Toolbar1.add(btnFind);
        Toolbar1.add(btnRetrieve);
        Toolbar1.add(btnCreate);
        Toolbar1.add(btnUpdate);
        Toolbar1.add(btnDelete);
        Toolbar1.add(btnSave);
        Toolbar1.add(btnCancel);
        Toolbar1.add(btnList);
        
        btnSave.setVisible(false);
        btnCancel.setVisible(false);  //atributos
        JPanel centro = new JPanel();
        centro.setLayout(new GridLayout(3, 2));
        centro.add(labelIdCategoria);
        centro.add(textFieldIdCategoria);
        centro.add(labelNomeCategoria);
        centro.add(textFieldNomeCategoria);
        aviso.add(labelAviso);
        aviso.setBackground(Color.yellow);
        cp.add(Toolbar1, BorderLayout.NORTH);
        cp.add(centro, BorderLayout.CENTER);
        cp.add(aviso, BorderLayout.SOUTH);
        textFieldIdCategoria.requestFocus();
        textFieldIdCategoria.selectAll();
        textFieldIdCategoria.setBackground(Color.GREEN);
        labelAviso.setText("Digite uma placa e clic [Pesquisar]");
//        setVisible(true);//faz a janela ficar visível  

// Listeners
        btnFind.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoCategoria.listStrings();
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldIdCategoria.setText(aux[0]);
                        clicarBotaoAutomaticamente(btnRetrieve, 0);
                    } else {
                        textFieldIdCategoria.requestFocus();
                        textFieldNomeCategoria.selectAll();
                    }
                }
            }

        });
        btnRetrieve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                categoria = new Categoria();
                textFieldIdCategoria.setText(textFieldIdCategoria.getText().trim());//caso tenham sido digitados espaços

                if (textFieldIdCategoria.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Deve ser informado um valor para esse campo");
                    textFieldIdCategoria.requestFocus();
                    textFieldIdCategoria.selectAll();
                } else {
                    categoria.setIdCategoria(Integer.valueOf(textFieldIdCategoria.getText()));
                    categoria = daoCategoria.obter(categoria.getIdCategoria());
                    if (categoria != null) { //se encontrou na lista
                     //   System.out.println("achou");
                        textFieldNomeCategoria.setText(categoria.getNomeCategoria());
                        atvBotoes(false, true, true, true);
                        habilitarAtributos(true, false);
                        labelAviso.setText("Encontrou - clic [Pesquisar], [Alterar] ou [Excluir]");
                        acao = "encontrou";
                    } else {
                        atvBotoes(true, true, false, false);
                        labelAviso.setText("Não cadastrado - clic [Inserir] ou digite outra id [Pesquisar]");
                    }
                }
            }
        });

        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                habilitarAtributos(false, true);
                textFieldNomeCategoria.requestFocus();
                mostrarBotoes(false);
                labelAviso.setText("Preencha os campos e clic [Salvar] ou clic [Cancelar]");
                acao = "insert";
            }
        });
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (acao.equals("insert")) {
                    categoria = new Categoria();
                    categoria.setIdCategoria(Integer.valueOf(textFieldIdCategoria.getText()));
                    categoria.setNomeCategoria(textFieldNomeCategoria.getText());
                    daoCategoria.inserir(categoria);
                    habilitarAtributos(true, false);
                    mostrarBotoes(true);
                    zerarAtributos();
                    atvBotoes(false, true, false, false);
                    labelAviso.setText("Registro inserido...");
                } else {  //acao = update
                    categoria.setIdCategoria(Integer.valueOf(textFieldIdCategoria.getText()));
                    categoria.setNomeCategoria(textFieldNomeCategoria.getText());

                    daoCategoria.atualizar(categoria);
                    mostrarBotoes(true);
                    habilitarAtributos(true, false);
                    zerarAtributos();
                    atvBotoes(false, true, false, false);
                    labelAviso.setText("Registro atualizado...");
                }
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos();
                atvBotoes(false, true, false, false);
                habilitarAtributos(true, false);
                mostrarBotoes(true);
            }
        });
        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                acao = "list";
                GUIListagemCategoria guiListagem = new GUIListagemCategoria((List<Categoria>) daoCategoria.list(), getBounds().x, getBounds().y);
            }
        });
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "update";
                mostrarBotoes(false);
                habilitarAtributos(false, true);
            }
        });
//---------------------------------------------------------
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(cp,
                        "Confirma a exclusão do registro <ID = " + categoria.getIdCategoria() + ">?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {
                    labelAviso.setText("Registro excluído...");
                    daoCategoria.remover(categoria);
                    zerarAtributos();
                    textFieldIdCategoria.requestFocus();
                    textFieldIdCategoria.selectAll();
                }
            }
        });
        textFieldIdCategoria.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldIdCategoria.setBackground(Color.GREEN);
                if (acao != "encontrou") {
                    labelAviso.setText("Digite uma Id_cartao e clic [Pesquisar]");
                }
            }

            @Override
            public void focusLost(FocusEvent fe) {
                textFieldIdCategoria.setBackground(Color.white);
            }
        });
        textFieldIdCategoria.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldIdCategoria.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldIdCategoria.setBackground(Color.white);
            }
        });
        textFieldNomeCategoria.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldNomeCategoria.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldNomeCategoria.setBackground(Color.white);
            }
        });
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //antes de sair do sistema, grava os dados da lista em disco
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        setModal(true);
        setVisible(true);
    }
}
