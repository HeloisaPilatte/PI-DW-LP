package GUIs;

import daos.DAOCliente;

import Entidades.Cliente;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;
import tools.CentroDoMonitorMaior;
import tools.CopiaImagem;
import tools.JanelaPesquisar;
import tools.MyJOptionPane;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GUICliente extends JDialog {

    ImageIcon iconeCreate = new ImageIcon(getClass().getResource("/icones/create.png"));
    ImageIcon iconeRetrieve = new ImageIcon(getClass().getResource("/icones/retrieve.png"));
    ImageIcon iconeUpdate = new ImageIcon(getClass().getResource("/icones/update.png"));
    ImageIcon iconeDelete = new ImageIcon(getClass().getResource("/icones/delete.png"));
    ImageIcon iconeSave = new ImageIcon(getClass().getResource("/icones/save.png"));
    ImageIcon iconeCancel = new ImageIcon(getClass().getResource("/icones/cancel.png"));
    ImageIcon iconeListar = new ImageIcon(getClass().getResource("/icones/list.png"));
    ImageIcon iconeGerar = new ImageIcon(GetImg("src/icones/download.png", 30, 30));
    
    private ImageIcon iconeFind = new ImageIcon(getClass().getResource("/icones/findCheck.png"));
    private ImageIcon iconeFindPequeno = new ImageIcon(getClass().getResource("/icones/find.png"));
    
    public Image GetImg(String origem, int x, int y) {
        ImageIcon imgIcone = new ImageIcon(origem);

        Image iIcone = imgIcone.getImage();
        Image Icone = iIcone.getScaledInstance(x, y, java.awt.Image.SCALE_SMOOTH);
        return Icone;
    }
    
    
    private JButton btnFind = new JButton(iconeFind);
    JButton btnCreate = new JButton(iconeCreate);
    JButton btnRetrieve = new JButton(iconeRetrieve);
    JButton btnUpdate = new JButton(iconeUpdate);
    JButton btnDelete = new JButton(iconeDelete);
    JButton btnSave = new JButton(iconeSave);
    JButton btnCancel = new JButton(iconeCancel);
    JButton btnList = new JButton(iconeListar);
    JButton btGerarPdf = new JButton(iconeGerar);
    JLabel labelId = new JLabel("Id");
    JTextField textFieldId = new JTextField(50);
    JLabel labelnome = new JLabel("Nome");
    JTextField textFieldNome = new JTextField(250);
    JLabel labeltelefone = new JLabel("Telefone");
    JTextField textFieldTelefone = new JTextField(250);
    JLabel labelendereco = new JLabel("Endereco");
    JTextField textFieldEndereco = new JTextField(250);
    JLabel labelSenha = new JLabel("Senha");
    JTextField textFieldSenha = new JTextField(50);
    JLabel labelFoto = new JLabel(" ");
    JPanel aviso = new JPanel();
    JLabel labelAviso = new JLabel("");
    String acao = "";

    Image imagemAux;
    String origem;
    String destino = "src/fotos/";

    DAOCliente daoCliente = new DAOCliente();
    Cliente cliente;

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    private void atvBotoes(boolean c, boolean r, boolean u, boolean d) {
        btnCreate.setEnabled(c);
        btnFind.setEnabled(r);
        btnRetrieve.setEnabled(r);
        btnUpdate.setEnabled(u);
        btnDelete.setEnabled(d);
        btnList.setEnabled(r);
    }

    public void mostrarBotoes(boolean visivel) {
        btnCreate.setVisible(visivel);
        btnRetrieve.setVisible(visivel);
        btnUpdate.setVisible(visivel);
        btnDelete.setVisible(visivel);
        btnList.setVisible(visivel);
        btnSave.setVisible(!visivel);
        btnCancel.setVisible(!visivel);
        btnFind.setVisible(visivel);
    }

    private void habilitarAtributos(boolean id, boolean nome, boolean telefone, boolean endereco, boolean cpf) {
        if (id) {
            textFieldId.requestFocus();
            textFieldId.selectAll();
        }
        textFieldId.setEnabled(id);
        textFieldId.setEditable(id);
        textFieldNome.setEditable(nome);
        textFieldTelefone.setEditable(telefone);
        textFieldEndereco.setEditable(endereco);
        textFieldSenha.setEditable(cpf);

    }

    public void zerarAtributos(int img) {
        textFieldNome.setText("");
        textFieldTelefone.setText("");
        textFieldEndereco.setText("");
        textFieldSenha.setText("");
        if (img == 0) {
            origem = "/fotos/0.png";
        } else {
            origem = "/fotos/0a.png";
        }

        ImageIcon icone = new ImageIcon(getClass().getResource(origem));

        imagemAux = icone.getImage();
        icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
        labelFoto.setIcon(icone);
    }

    public GUICliente() {

        setTitle("Cadastro Cliente");
        setSize(800, 500);//tamanho da janela
        Point p = new CentroDoMonitorMaior().getCentroMonitorMaior(this);
        setLocation(p);
        Dimension dimensao = getSize();
        setLayout(new BorderLayout());//informa qual gerenciador de layout será usado
        setBackground(Color.CYAN);//cor do fundo da janela
        Container cp = getContentPane();//container principal, para adicionar nele os outros componentes

        atvBotoes(false, true, false, false);
        habilitarAtributos(true, false, false, false, false);
        btnCreate.setToolTipText("Inserir novo registro");
        btnRetrieve.setToolTipText("Pesquisar por chave");
        btnFind.setToolTipText("Pesquisar em lista");
        btnUpdate.setToolTipText("Alterar");
        btnDelete.setToolTipText("Excluir");
        btnList.setToolTipText("Listar todos");
        btnSave.setToolTipText("Salvar");
        btnCancel.setToolTipText("Cancelar");
        btGerarPdf.setToolTipText("Gerar PDF");
        JToolBar Toolbar1 = new JToolBar();

        Toolbar1.add(textFieldId);
        Toolbar1.add(btnFind);
        Toolbar1.add(btnRetrieve);
        Toolbar1.add(btnCreate);
        Toolbar1.add(btnUpdate);
        Toolbar1.add(btnDelete);
        Toolbar1.add(btnSave);
        Toolbar1.add(btnCancel);
        Toolbar1.add(btnList);
        Toolbar1.add(btGerarPdf);

        btnSave.setVisible(false);
        btnCancel.setVisible(false);

        JPanel painelCentro = new JPanel(new BorderLayout());
        JPanel centroDireita = new JPanel(new GridLayout(1, 1));
        JPanel centroEsquerda = new JPanel();
        centroDireita.add(labelFoto);

        painelCentro.add(centroEsquerda, BorderLayout.CENTER);//painel dos atributos texto
        painelCentro.add(centroDireita, BorderLayout.EAST);//painel da foto

        centroEsquerda.setLayout(new GridLayout(5, 2));
        centroEsquerda.add(labelId);
        centroEsquerda.add(textFieldId);
        centroEsquerda.add(labelnome);
        centroEsquerda.add(textFieldNome);
        centroEsquerda.add(labeltelefone);
        centroEsquerda.add(textFieldTelefone);
        centroEsquerda.add(labelendereco);
        centroEsquerda.add(textFieldEndereco);
        centroEsquerda.add(labelSenha);
        centroEsquerda.add(textFieldSenha);

        aviso.add(labelAviso);
        aviso.setBackground(Color.yellow);
        cp.add(Toolbar1, BorderLayout.NORTH);
        cp.add(painelCentro, BorderLayout.CENTER);
        cp.add(aviso, BorderLayout.SOUTH);
        textFieldId.requestFocus();
        textFieldId.selectAll();
        textFieldId.setBackground(Color.GREEN);
        labelAviso.setText("Digite uma id e clic [Pesquisar]");

        //para ajustar o tamanho de uma imagem
        try {
            origem = "/fotos/0.png";
            ImageIcon icone = new ImageIcon(getClass().getResource(origem));
            imagemAux = icone.getImage();
            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
            labelFoto.setIcon(icone);

        } catch (Exception e) {
            System.out.println("erro ao carregar a imagem");
        }

        // Listeners
        btnFind.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoCliente.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x - getWidth() / 2 + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        textFieldId.setText(aux[0]);
                        clicarBotaoAutomaticamente(btnRetrieve, 0);
                    } else {
                        textFieldId.requestFocus();
                        textFieldNome.selectAll();
                    }
                }
            }
        });

        btnRetrieve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    cliente = new Cliente();
                    cliente.setIdCliente(Integer.valueOf(textFieldId.getText()));

                    textFieldId.setText(textFieldId.getText().trim());//caso tenham sido digitados espaços
                    if (textFieldId.getText().equals("")) {
                        JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para esse campo");
                        textFieldId.requestFocus();
                        textFieldId.selectAll();
                    } else {
                        cliente = daoCliente.obter(cliente.getIdCliente());
                        if (cliente != null) { //se encontrou na lista
                            textFieldNome.setText(cliente.getNomeCliente());
                            textFieldTelefone.setText(cliente.getTelefoneCliente());
                            textFieldEndereco.setText(cliente.getEnderecoCliente());
                            textFieldSenha.setText(cliente.getSenhaCliente());
                            atvBotoes(false, true, true, true);
                            habilitarAtributos(true, false,false,false, false);
                            labelAviso.setText("Encontrou - clic [Pesquisar], [Alterar] ou [Excluir]");
                            acao = "encontrou";

                            //para ajustar o tamanho de uma imagem
                            try {
                                String aux = String.valueOf(cliente.getIdCliente()).trim();
                                origem = "/fotos/" + aux + ".png";
                                ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                                imagemAux = icone.getImage();
                                icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));

                                labelFoto.setIcon(icone);

                            } catch (Exception e) {
                                System.out.println("nao achou " + origem);
                                origem = "/fotos/0.png";
                                ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                                imagemAux = icone.getImage();
                                icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
                                labelFoto.setIcon(icone);
                            }

                        } else {
                            atvBotoes(true, true, false, false);
                            zerarAtributos(0);
                            labelAviso.setText("Não cadastrado - clic [Inserir] ou digite outra id [Pesquisar]");
                        }
                    }
                } catch (Exception e) {
                    labelAviso.setText("Erro na entrada de dados");
                }
            }
        });
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos(1);
                habilitarAtributos(false, true,true,true, true);
                textFieldNome.requestFocus();
                mostrarBotoes(false);
                labelAviso.setText("Preencha os campos e clic [Salvar] ou clic [Cancelar]");
                acao = "insert";
            }
        });
        btnSave.addActionListener(new ActionListener() {
            private String erro;

            @Override
            public void actionPerformed(ActionEvent ae) {
                this.erro = "";
                if (textFieldNome.getText().equals("") || textFieldSenha.getText().equals("")) {
                    JOptionPane.showMessageDialog(cp, "Deve ser informado um valor para todos os campos!");
                } else {
                    if (acao.equals("insert")) {
                        cliente = new Cliente();
                        cliente.setIdCliente(Integer.valueOf(textFieldId.getText()));
                        cliente.setNomeCliente(textFieldNome.getText());
                        cliente.setTelefoneCliente(textFieldTelefone.getText());
                        cliente.setEnderecoCliente(textFieldEndereco.getText());
                        cliente.setSenhaCliente(textFieldSenha.getText());
                        daoCliente.inserir(cliente);
                        habilitarAtributos(true, false, false, false, false);
                        mostrarBotoes(true);
                        atvBotoes(false, true, false, false);
                        labelAviso.setText("Registro inserido...");
                    } else {  //acao = update
                        cliente.setIdCliente(Integer.valueOf(textFieldId.getText()));
                        cliente.setNomeCliente(textFieldNome.getText());
                         cliente.setTelefoneCliente(textFieldTelefone.getText());
                        cliente.setEnderecoCliente(textFieldEndereco.getText());
                        cliente.setSenhaCliente(textFieldSenha.getText());
                        daoCliente.atualizar(cliente);
                        labelAviso.setText("atualizado");
                        mostrarBotoes(true);
                        habilitarAtributos(true, false, false, false, false);
                        atvBotoes(false, true, false, false);

                    }
                    //salvar a imagem
                    destino = destino + cliente.getIdCliente() + ".png";
//                    System.out.println("origem =>" + origem);
//                    System.out.println("destino =>" + destino);
                    CopiaImagem.copiar(origem, destino);
                    destino = "src/fotos/";

                }
            }
        });

        labelFoto.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (acao.equals("insert") || acao.equals("update")) {
                    JFileChooser fc = new JFileChooser();
                    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    if (fc.showOpenDialog(cp) == JFileChooser.APPROVE_OPTION) {
                        File img = fc.getSelectedFile();
                        origem = fc.getSelectedFile().getAbsolutePath();
                        try {
                            ImageIcon icone = new javax.swing.ImageIcon(img.getAbsolutePath());
                            Image imagemAux;
                            imagemAux = icone.getImage();
                            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
                            labelFoto.setIcon(icone);

                        } catch (Exception ex) {
                            System.out.println("Erro: " + ex.getMessage());
                        }
                    }

                }

            }
        });

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                zerarAtributos(0);
                atvBotoes(false, true, false, false);
                habilitarAtributos(true, false, false, false, false);
                mostrarBotoes(true);
            }
        });
        btnList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "list";
                GUIListagemCliente guiListagem = new GUIListagemCliente(daoCliente.listInOrderNome(), getBounds().x, getBounds().y);
            }
        });
        
        btGerarPdf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
            
             Document document = new Document();
        
        try {
                 try {
                     PdfWriter.getInstance(document, new FileOutputStream("documento"+cliente.getIdCliente()+".pdf"));
                 } catch (FileNotFoundException ex) {
                     Logger.getLogger(GUICliente.class.getName()).log(Level.SEVERE, null, ex);
                 }
            
            document.open();
            document.add(new Paragraph(
                    "\n Id Cliente: "+ String.valueOf(cliente.getIdCliente())
                    + "\n  Senha Cliente: "+ cliente.getSenhaCliente()
                    + "\n Nome Cliente: "+ cliente.getNomeCliente()
                    + "\n Endereco Cliente: "+ cliente.getEnderecoCliente()
                    + "\n TelefoneCliente: "+ cliente.getTelefoneCliente()
            ));
                           
            
            
        } catch (DocumentException ex) {
            System.out.println("Error:"+ex);
        }finally{
            document.close();
        }
        
        try {
            Desktop.getDesktop().open(new File("documento"+cliente.getIdCliente()+".pdf"));
        } catch (IOException ex) {
            System.out.println("Error:"+ex);
        }
            
            }
                
      });
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                acao = "update";
                mostrarBotoes(false);
                habilitarAtributos(false, true, true, true, true);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                if (new MyJOptionPane(new Point(p.x + dimensao.width / 2, p.y + dimensao.height / 2), "Excluir?").getValorRetornado()) {

                    String aux = String.valueOf(cliente.getIdCliente()).trim();
                    origem = "src/fotos/" + aux + ".png";
                    // System.out.println(origem);
                    try {
                        File f = new File(origem);
                        if (f.exists()) {
                            f.delete();
                        }
                    } catch (Exception e) {
                        System.out.println("foto não deletada");
                    }

                    daoCliente.remover(cliente);
                    labelAviso.setText("");
                    zerarAtributos(0);
                    textFieldId.requestFocus();
                    textFieldId.selectAll();
                } else {
                    labelAviso.setText("Exclusão cancelada");
                    textFieldId.requestFocus();
                    textFieldId.selectAll();
                }

            }
        });
        textFieldId.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldId.setBackground(Color.GREEN);
                if (acao != "encontrou") {
                    labelAviso.setText("Digite uma id e clic [Pesquisar]");
                }
            }

            @Override
            public void focusLost(FocusEvent fe) {
                textFieldId.setBackground(Color.white);
            }
        });
        textFieldId.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldId.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldId.setBackground(Color.white);
            }
        });
        textFieldNome.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldNome.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldNome.setBackground(Color.white);
            }
        });
          textFieldTelefone.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldTelefone.setBackground(Color.GREEN);
            }
 
            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldTelefone.setBackground(Color.white);
            }
        });
        textFieldEndereco.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldEndereco.setBackground(Color.GREEN);
            }
 
            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldEndereco.setBackground(Color.white);
            }
        });  
        textFieldSenha.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                textFieldSenha.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                textFieldSenha.setBackground(Color.white);
            }
        });

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //antes de sair do sistema, grava os dados da lista em disco
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        setModal(true);
        setVisible(true);
        pack();
    }

}
