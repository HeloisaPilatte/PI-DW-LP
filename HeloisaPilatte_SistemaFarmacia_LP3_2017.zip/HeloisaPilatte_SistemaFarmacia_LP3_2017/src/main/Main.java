package main;


import java.awt.Dimension;

/**
 *
 * @author radames
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Dimension dimensao = new Dimension(800, 400);
        new GUIs.MenuPrincipal(dimensao);
   //     new GUICardapioHasAlimento();
        //     new CardapioHasAlimentoGUITableModel();

        // new GUIMedida();
//        DAOUnidadeDeMedida daoUnidadeDeMedida = new DAOUnidadeDeMedida();
//        UnidadeDeMedida unidadeDeMedida = new UnidadeDeMedida();
//        unidadeDeMedida.setIdUnidadeDeMedida("KG");
//        unidadeDeMedida.setNomeUnidadeDeMedida("Quilograma");
//        try {
//            daoUnidadeDeMedida.inserir(unidadeDeMedida);
//        } catch (Exception e) {
//            String [] aux = e.getMessage().split("Error Code:");
//            aux[1]=aux[1].trim();
//            System.out.println("====>"+aux[1].substring(0, 4));
//        }
    }

}
