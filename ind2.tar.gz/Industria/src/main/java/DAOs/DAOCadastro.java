package DAOs;


import Entidades.Cadastro;
import java.util.ArrayList;
import java.util.List;
public class DAOCadastro extends DAOGenerico<Cadastro> {
public DAOCadastro() {
        super(Cadastro.class);
    }
public int autoCnpjCadastro() {
Integer a = (Integer) em.createQuery("SELECT MAX(e.cnpjCadastro) FROM Cadastro e ").getSingleResult();
if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }
 public List<Cadastro> listByNome(String nome) {
return em.createQuery("SELECT e FROM Cadastro e WHERE e.nomeCadastro LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }
public List<Cadastro> listByCnpj(int cnpj) {
 return em.createQuery("SELECT e FROMCadastro  e WHERE e.cnpjCadastro = :cnpj").setParameter("cnpj", cnpj).getResultList();
    }
public List<Cadastro> listInOrderNome() {
 return em.createQuery("SELECT e FROM Cadastro e ORDER BY e.nomeCadastro").getResultList();
    }
public List<Cadastro> listInOrderCnpj() {
return em.createQuery("SELECT e FROM Cadastro e ORDER BY e.cnpjCadastro").getResultList();
    }
public List<String> listInOrderNomeStrings(String qualOrdem) {
List<Cadastro> lf;
if (qualOrdem.equals("cnpj")) {
lf = listInOrderCnpj();
} else {
lf = listInOrderNome();}
List<String> ls = new ArrayList<>();
for (int i = 0; i < lf.size(); i++) {
ls.add(lf.get(i).getCnpjCadastro() + "-" + lf.get(i).getNomeCadastro());}
return ls;}}
