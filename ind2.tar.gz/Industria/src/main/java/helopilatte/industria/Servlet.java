/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helopilatte.industria;

import DAOs.DAOCadastro;
import Entidades.Cadastro;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hello
 */
@WebServlet(name = "empresa", urlPatterns = {"/empresa"})
public class Servlet extends HttpServlet {

    List<Cadastro> lista = new ArrayList<>();
    DAOCadastro controle = new DAOCadastro();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("aaaa");

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            out.println("</head>");
            out.println("<body>");
           
            lista = controle.list();
            String x[];

            for (Cadastro linha : lista) {
                x = String.valueOf(linha).split(";");

                out.println("<p> <b>Dados Farmácia --> CNPJ: </b>" + Integer.valueOf(x[0]) + ""
                        + "  <b>Nome: </b>" + x[1] + ""
                        + "  <b>Email: </b>" + x[2] + ""
                        + "  <b>Senha: </b>" + x[3] + "</p>");
            }

            out.println("<h4>" + " <a href= \"index.jsp\"> Voltar a página inicial</a></h4>");

            out.println("</body>");
            out.println("</html>");

        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String cnpj = request.getParameter("cnpj");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");

        Cadastro cadastro = new Cadastro();

        if (cnpj != null) {
            cadastro.setCnpjCadastro(Integer.valueOf(cnpj));
        }

        if (nome != null) {
            cadastro.setNomeCadastro(nome);
        }

        if (email != null) {
            cadastro.setEmailCadastro(email);
        }

        if (senha != null) {
            cadastro.setSenhaCadastro(senha);
        }

        controle.inserir(cadastro);
        System.out.println("FUNCIONOU");

        processRequest(request, response);

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
