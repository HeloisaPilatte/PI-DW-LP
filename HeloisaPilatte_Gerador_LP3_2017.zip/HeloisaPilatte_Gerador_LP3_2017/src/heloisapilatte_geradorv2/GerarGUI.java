package heloisapilatte_geradorv2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author a1603116
 */
public class GerarGUI {

    public GerarGUI(String caminho) {
        System.out.println(caminho);
        List<String> descricaoEntidade = new ArrayList<>();
        List<String> codigo = new ArrayList<>();
        File file = new File(caminho);
        String nomeClasse = file.getName();

        String auxA[] = nomeClasse.split("\\.");
        nomeClasse = auxA[0];
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        STRS strs = new STRS();
        descricaoEntidade = manipulaArquivo.abrirArquivo(caminho);

        if (descricaoEntidade == null) {
            System.out.println("Não achou o arquivo com o nome e atributos da classe....");
            System.exit(0); //aborta o programa
        }
        int numAtributos = 0;
        String[] nomeAtributos = new String[descricaoEntidade.size()];
        String[] tipoAtributos = new String[descricaoEntidade.size()];
        String[] inicioAtributos = new String[descricaoEntidade.size()];

        for (int i = 0; i < descricaoEntidade.size(); i++) {
            numAtributos++;
            String[] aux = descricaoEntidade.get(i).split(";");
            nomeAtributos[i] = aux[0];
            tipoAtributos[i] = aux[1];
            inicioAtributos[i] = aux[2];
            if (aux[1].equals("int")) {
                tipoAtributos[i] = "Integer";
            }
        }

        String modeloData = "";
        for (int j = 0; j < numAtributos; j++) {
            if (tipoAtributos[j].equals("Date")) {
                modeloData = "dd/MM/yyyy";
            }

        }
        String op = "";
        String valor1 = "";
        String valor2 = "";

        codigo.add("package classeGerada;");
        codigo.add("import java.awt.BorderLayout;\n"
                + "import java.awt.Color;\n"
                 + "import DAOs.DAO"+nomeClasse+";\n"
                + "import Entidades." + nomeClasse + ";\n"
                + "import java.text.ParseException;\n"
                + "import java.awt.Container;\n"
                + "import java.awt.FlowLayout;\n"
                + "import java.awt.GridLayout;\n"
                + "import java.awt.event.ActionEvent;\n"
                + "import java.awt.event.ActionListener;\n"
                + "import java.awt.event.WindowAdapter;\n"
                + "import java.awt.event.WindowEvent;\n"
                + "import javax.swing.JButton;\n"
                + "import javax.swing.JCheckBox;\n"
                + "import java.text.SimpleDateFormat;\n"
                + "import java.util.Date;\n"
                + "import java.util.List;\n"
                + "import java.util.ArrayList;\n"
                + "import javax.swing.JFrame;\n"
                + "import javax.swing.JOptionPane;\n"
                + "import javax.swing.JLabel;\n"
                + "import javax.swing.JOptionPane;\n"
                + "import javax.swing.JPanel;\n"
                + "import javax.swing.JRadioButton;\n"
                + "import javax.swing.ButtonGroup;\n"
                + "import javax.swing.JTextField;\n");
        codigo.add("public class GUI" + nomeClasse + " extends JFrame {");
        codigo.add("private Container cp;");
        codigo.add("private JPanel pnNorte = new JPanel(new FlowLayout());\n"
                + "    private JPanel pnCentro = new JPanel(new FlowLayout());\n "
                + "    private JPanel pnSul = new JPanel(new FlowLayout());"
                + "    private JPanel pnAuxiliar = new JPanel(new GridLayout(" + (numAtributos - 1) + ", 2));\n");

        codigo.add("    private JButton btBuscar = new JButton(\"Buscar\");\n"
                + "    private JButton btAdicionar = new JButton(\"Adicionar\");\n"
                + "    private JButton btSalvar = new JButton(\"Salvar\");\n"
                + "    private JButton btCancelar = new JButton(\"Cancelar\");\n"
                + "    private JButton btRemover = new JButton(\"Remover\");\n"
                + "    private JButton btAtualizar = new JButton(\"Atualizar\");\n"
                + "    private JButton btListar = new JButton(\"Listagem\");"
                + "");
        System.out.println("-----------------------------------------------------------------------------------------------");
        for (int i = 0; i < numAtributos; i++) {
            System.out.println(tipoAtributos[i]);
            if (tipoAtributos[i].equals("Date")) {
                codigo.add("private JLabel l" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + " = new JLabel(\"" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ": -> dd/MM/yyyy \");\n "
                        + "DateTextField tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + " = new DateTextField();\n");

            } else if (tipoAtributos[i].equals("boolean")) {
                codigo.add("private JLabel l" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + " = new JLabel(\"" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + "\"" + ");\n"
                );
                System.out.println("fcs");
                //**********************

                valor1 = JOptionPane.showInputDialog("Insira o primeiro valor desejado para " + nomeAtributos[i] + " : ", "Entrada de Dados");

                valor2 = JOptionPane.showInputDialog("Insira o segundo valor desejado para " + nomeAtributos[i] + " : ", "Entrada de Dados");
                op = JOptionPane.showInputDialog("Digite rb para Rádio Button e cb para Check Box:");
                if (op.equals("rb")) {
                    codigo.add("private ButtonGroup grupo = new ButtonGroup();\n"
                            + "private JRadioButton rbt = new JRadioButton(\"" + valor1 + "\", true);\n"
                            + "    private JRadioButton rbf = new JRadioButton(\"" + valor2 + "\", false);\n"
                            + "    private JPanel pncentroradio = new JPanel();\n");
                } else if (op.equals("cb")) {
                    codigo.add("private JCheckBox op1,op2;");

                    //************
                }
            } else {
                codigo.add("private JLabel l" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + " = new JLabel(\"" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ":\");\n "
                        + "private JTextField tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + "= new JTextField(30);\n");

            }

        }

        codigo.add("private JLabel lAviso = new JLabel(\"Aviso:\");\n"
                + "DAO" + nomeClasse + " controle = new DAO" + nomeClasse + "();\n"
                + "private boolean acao = true;\n"
                + nomeClasse + " " + nomeClasse.toLowerCase() + " = new " + nomeClasse + "();");

        codigo.add(" ManipulaArquivo manipulaArquivo = new ManipulaArquivo();\n"
                + "    List<String> dados = new ArrayList<>();\n"
                + "    SimpleDateFormat sdf = new SimpleDateFormat(\"dd/MM/yyyy\");"
                + "\n" + "    public GUI" + nomeClasse + "() throws ParseException{\n"
        );
        
        
        codigo.add("\n" + "        setSize(800, 300);\n"
                + "        setDefaultCloseOperation(DISPOSE_ON_CLOSE);\n"
                + "        cp = getContentPane();\n"
                + "        cp.setLayout(new BorderLayout());\n"
                + "        setTitle(\"" + nomeClasse + "\");\n"
                + "        pnNorte.setBackground(Color.BLUE);\n"
                + "        pnCentro.setBackground(Color.GRAY);\n"
                + "        pnSul.setBackground(Color.RED);\n"
                + "\n");

        codigo.add(
                "        pnNorte.add(l" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ");\n"
                + "        pnNorte.add(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ");\n"
                + "        pnNorte.add(btBuscar);\n"
                + "        pnNorte.add(btAdicionar);\n"
                + "        pnNorte.add(btSalvar);\n"
                + "        pnNorte.add(btCancelar);\n"
                + "        pnNorte.add(btRemover);\n"
                + "        pnNorte.add(btAtualizar);\n"
                + "        pnNorte.add(btListar);\n"
                + "        btAdicionar.setVisible(false);\n"
                + "        btSalvar.setVisible(false);\n"
                + "        btCancelar.setVisible(false);\n"
                + "        btRemover.setVisible(false);\n"
                + "        btAtualizar.setVisible(false);");

        String auxiliar2 = "";
        for (int i = 1; i < numAtributos; i++) {
            //erooooooooooooooooooooooooooooo
            if (tipoAtributos[i].equals("boolean")) {
                if (op.equals("rb")) {

                    codigo.add("grupo.add(rbt);");

                    codigo.add("grupo.add(rbf);");

                    codigo.add("pncentroradio.add(l" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ");");

                    codigo.add("pncentroradio.add(rbt);");

                    codigo.add("pncentroradio.add(rbf);");

                    codigo.add("pncentroradio.setBackground(Color.YELLOW);");

                    codigo.add("pnCentro.add(pncentroradio);");
                } else if (op.equals("cb")) {
                    codigo.add("op1 = new JCheckBox(\"" + valor1 + "\");\n"
                            + " op2 = new JCheckBox(\"" + valor2 + "\");");
                    codigo.add(" pnAuxiliar.add(op1);\n"
                            + "        pnAuxiliar.add(op2);");

                } else {

                    auxiliar2 += "        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ".setEnabled(false); \n";
                }
            } else if (tipoAtributos[i].equals("Date")) {
                codigo.add("DateTextField " + nomeAtributos[i] + " = new DateTextField();");
            }

        }
        codigo.add(auxiliar2);
        codigo.add("        pnAuxiliar.setLayout(new GridLayout(" + (numAtributos - 1) + ",2));");
        String auxiliar3 = "";
        for (int i = 1; i < numAtributos; i++) {

            if (tipoAtributos[i].equals("boolean")) {

            } else {
                auxiliar3 += "        pnAuxiliar.add(l" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + "); \n"
                        + "        pnAuxiliar.add(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ");\n";

            }
        }
        codigo.add(auxiliar3 + "\n" + "        pnCentro.add(pnAuxiliar); \n"
                + "        pnSul.add(lAviso);\n"
                + "        cp.setLayout(new BorderLayout());\n"
                + "        cp.add(pnNorte, BorderLayout.NORTH);\n"
                + "        cp.add(pnSul, BorderLayout.SOUTH);\n"
                + "        cp.add(pnCentro, BorderLayout.CENTER);\n"
                + "btBuscar.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        try {\n"
                + "                            " + nomeClasse.toLowerCase() + " = new " + nomeClasse + "();\n");
        String auxiliarExtra = "";
        auxiliarExtra = "                            String " + nomeAtributos[0].toLowerCase() + " = String.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText());\n"
                + "                            " + nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) +nomeClasse+"(" + nomeAtributos[0].toLowerCase() + ");\n";

        if (tipoAtributos[0].equals("String")) {
            codigo.add(auxiliarExtra);
        } else {
            codigo.add(
                    "                            int " + nomeAtributos[0].toLowerCase() + " = Integer.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText());\n"
                    + "                            " + nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) +nomeClasse +"(" + nomeAtributos[0].toLowerCase() + ");\n"
                    + "                            if (" + nomeAtributos[0].toLowerCase() + " <= 0) {\n"
                    + nomeAtributos[0].toLowerCase() + "=" + nomeAtributos[0].toLowerCase() + "/ 0;\n }");
        }
        codigo.add("\n"
                + "                                " + nomeClasse.toLowerCase() + " = controle.obter(" + nomeClasse.toLowerCase() +".get" +strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse+"());\n"
                + "\n"
                + "                                if (" + nomeClasse.toLowerCase() + " != null) {\n"
        );
        String auxiliar4 = "";
        for (int i = 1; i < numAtributos; i++) {
            if (tipoAtributos[i].equals("Date")) {
                auxiliar4 += "tf"+strs.primeiraLetraMaiuscula(nomeAtributos[i])
                        + ".setText(sdf.format(" + nomeClasse.toLowerCase()
                        + ".get" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse + "()));\n";

            } else if (tipoAtributos[i].equals("boolean")) {
                /////////////////////************mecher nome entidade....
                if (op.equals("rb")) {
                    auxiliar4 += "if (" + nomeClasse.toLowerCase() + ".is" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + "()) {\n"
                            + "                                    rbt.setSelected(true);\n"
                            + "                                } else {\n"
                            + "                                    rbf.setSelected(false);\n"
                            + "                                }\n";

                }
            } else {
                auxiliar4 += "                                    tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i])
                        + ".setText(String.valueOf(" + nomeClasse.toLowerCase()
                        + ".get" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse + "()));\n";
            }
        }
        codigo.add(auxiliar4);
        codigo.add("                                    lAviso.setBackground(Color.green);\n"
                + "                                    lAviso.setText(\"Encontrado\");\n"
                + "\n"
                + "                                    btAtualizar.setVisible(true);\n"
                + "                                    btRemover.setVisible(true);\n"
                + "                                    btAdicionar.setVisible(false);\n"
                + "                                } else {\n"
                + "                                    btAdicionar.setVisible(true);\n"
                + "                                    btAtualizar.setVisible(false);\n"
                + "                                    btRemover.setVisible(false);\n" + "\n"
                + auxiliar2
                + "\n"
                + "                                    lAviso.setBackground(Color.red);\n"
                + "                                    lAviso.setText(\"NÃ£o encontrado\");\n"
                + "\n"
                + "                                }\n"
                + "                            }\n"
                + "                        catch (Exception e1){\n"
                + "                            JOptionPane.showMessageDialog(null, \"Erro de inserção dos dados, verifique as informações\");}\n"
                + "\n" + "                        }\n"
                + "                }\n"
                + "        );\n"
                + "btAdicionar.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        acao = true;\n"
                + "                        btBuscar.setVisible(false);\n"
                + "\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".setEnabled(false);");
        String auxiliar5 = "";
        for (int i = 1; i < numAtributos; i++) {
            if (tipoAtributos[i].equals("boolean")) {
                if (op.equals("rb")) {
                    auxiliar5 += "rbf.set"
                            + "Enabled(true); \n rbt.setEnabled(true);\n";
                }
            } else if (tipoAtributos[i].equals("Date")) {
                auxiliar5 += "" + nomeAtributos[i] + ".setEnabled(true); \n";
            } else {
                auxiliar5 += "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ".setEnabled(true); \n";
            }
        }
        codigo.add("                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + ".requestFocus();\n"
        );
        String auxiliar6 = "";
        for (int i = 1; i < numAtributos; i++) {
            if (tipoAtributos[i].equals("boolean")) {

            } else {
                auxiliar6 += "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ".setText(\"\");\n";
            }
        }
        codigo.add(auxiliar5 + auxiliar6);
        codigo.add("                        btAdicionar.setVisible(false);\n"
                + "                        btSalvar.setVisible(true);\n"
                + "                        btCancelar.setVisible(true);\n"
                + "                        btRemover.setVisible(false);\n"
                + "                        btAtualizar.setVisible(false);\n"
                + "                    }\n"
                + "                }\n"
                + "        );"
                + "btSalvar.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        " + nomeClasse + " " + nomeClasse.toLowerCase() + " = new " + nomeClasse + "();\n"
                + "                        try{"
                + "                        " + nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse + "");
        auxiliarExtra = "(String.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText()));\n";
        if (tipoAtributos[0].equals("String")) {
            codigo.add(auxiliarExtra);
        } //*******************alterar entidade.....
        else if (tipoAtributos[0].equals("boolean")) {
            codigo.add(nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse + "(rbt.isSelected());");

        } else {
            codigo.add("(Integer.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText()));\n");
        }

        String auxiliar7 = "";

        for (int i = 1; i < numAtributos; i++) {
            if (tipoAtributos[i].equals("Date")) {
                auxiliar7 += "                        "
                        + nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse
                        + "(sdf.parse(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ".getText()));\n";
                System.out.println("errado");
            } else if (tipoAtributos[i].equals("boolean")) {
                if (op.equals("rb")) {
                    auxiliar7 += nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse + " (Boolean.valueOf(rbf.isSelected()));";
                    //*****************************************Mudar Sexo; entidade.......        
                } else if (op.equals("cb")) {
                    auxiliar7 += nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse + " (Boolean.valueOf(op1.isSelected()));";
                    auxiliar7 += nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + nomeClasse+" (Boolean.valueOf(op2.isSelected()));";
                }
            } else {
                auxiliar7 += nomeClasse.toLowerCase() + ".set" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse
                        + "(" + strs.primeiraLetraMaiuscula(tipoAtributos[i]) + ".valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[i]) + ".getText()));\n";

            }
        }
        codigo.add(auxiliar7 + "\n"
                + "if (acao) {//inserir\n"
                + "\n"
                + "                            List<String> lista" + nomeClasse + " = new ArrayList();\n"
        );

        String auxiliar8 = "";
        for (int i = 0; i < numAtributos; i++) {
            auxiliar8 += "                             lista" + nomeClasse + ".add(String.valueOf(" + nomeClasse.toLowerCase()
                    + ".get" + strs.primeiraLetraMaiuscula(nomeAtributos[i])+nomeClasse + "()));\n";
        }
        codigo.add(auxiliar8
                + "\n"
                + "                            controle.inserir(" + nomeClasse.toLowerCase() + ");\n"
                + "                            lAviso.setText(\"Registro inserido\");\n"
                + "\n"
                + "                        } else {//alterar\n"
                + "                            " + nomeClasse + " x = new " + nomeClasse + "();\n");
        auxiliarExtra = "x.set" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) +nomeClasse+ "(String.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText()));\n";
        if (tipoAtributos[0].equals("String")) {
            codigo.add(auxiliarExtra);
        } else {
            codigo.add(" x.set" + strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse + "(Integer.valueOf(tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".getText()));\n");
        }

        codigo.add("                            x = controle.obter(x.get"+strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse+"());\n"
                + "                            controle.atualizar("+ nomeClasse.toLowerCase() + ");\n"
                + "\n"
                + "                            lAviso.setText(\"Registro alterado\");\n"
                + "                        }\n"
                + "\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".setEnabled(true);\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".requestFocus();\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".selectAll();\n"
                + auxiliar2
                + "                        btSalvar.setVisible(false);\n"
                + "                        btCancelar.setVisible(false);\n"
                + "                        btBuscar.setVisible(true);\n"
                + "                    }\n"
                + "catch (Exception exbui) {\n"
                + " JOptionPane.showMessageDialog(null,\"Erro na inserção dos dados\");"
                + "                }}}\n"
                + "        );");
        codigo.add("btCancelar.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        lAviso.setText(\"Cancelado\");\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".setEnabled(true);\n"
                + "\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".requestFocus();\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".selectAll();\n"
                + "\n" + auxiliar2
                + "\n"
                + "                        btSalvar.setVisible(false);\n"
                + "                        btCancelar.setVisible(false);\n"
                + "                        btBuscar.setVisible(true);\n"
                + "\n" + auxiliar6 + "\n}\n"
                + "}\n"
                + ");");
        codigo.add("btAtualizar.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        acao = false;\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".setEnabled(false);\n"
                + auxiliar5
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + ".requestFocus();\n"
                + "                        btSalvar.setVisible(true);\n"
                + "                        btCancelar.setVisible(true);\n"
                + "                        btBuscar.setVisible(false);\n"
                + "                        btRemover.setVisible(false);\n"
                + "                        btAtualizar.setVisible(false);\n"
                + "\n"
                + "                    }\n"
                + "                }\n"
                + ");");
        codigo.add("btRemover.addActionListener(\n"
                + "                new ActionListener() {\n"
                + "\n"
                + "                    @Override\n"
                + "                    public void actionPerformed(ActionEvent e\n"
                + "                    ) {\n"
                + "                        btRemover.setVisible(false);\n"
                + "                        btAtualizar.setVisible(false);\n"
                + "                        if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,\n"
                + "                                \"Confirma a exclusÃ£o do registro <" + nomeAtributos[0].toUpperCase() + "= \" + " + nomeClasse.toLowerCase() + ".get"
                + strs.primeiraLetraMaiuscula(nomeAtributos[0])+nomeClasse + "() + \">?\", \"Confirm\",\n"
                + "                                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {\n"
                + "\n"
                + "                            controle.remover(" + nomeClasse.toLowerCase() + ");\n"
                + "                            lAviso.setText(\"Removeu\");\n"
                + auxiliar6
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".setEnabled(true);\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".requestFocus();\n"
                + "                        tf" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + ".selectAll();\n"
                + "\n"
                + "                        } else {\n"
                + "                            lAviso.setText(\"Cancelada a remoÃ§Ã£o\");\n"
                + "                            btRemover.setVisible(true);\n"
                + "                            btAtualizar.setVisible(true);\n"
                + "                        }\n"
                + "\n"
                + "                    }\n"
                + "                }\n"
                + "        );\n"
                + "btListar.addActionListener(new ActionListener() {\n"
                + "\n"
                + "            @Override\n"
                + "            public void actionPerformed(ActionEvent ae) {\n"
                + "              " + nomeClasse + "GUIListagem " + nomeClasse.toLowerCase() + "GuiListagem;\n"
                + "              List<" + nomeClasse + "> lista" + nomeClasse + " = controle.list();\n"
                + "                for (" + nomeClasse + " a : lista" + nomeClasse + ") {\n"
                + "                    dados.add(a.toString());\n"
                + "                }\n"
                + "                " + nomeClasse.toLowerCase() + "GuiListagem = new " + nomeClasse + "GUIListagem(lista" + nomeClasse + ",400,400);\n"
                + "    \n"
                + "             }\n"
                + "        });");
        codigo.add("addWindowListener(new WindowAdapter() {\n"
                + "            @Override\n"
                + "            public void windowClosing(WindowEvent e) {\n"
                             
                + "                System.exit(0);\n"
                + "            }\n"
                + "        });\n"
                + "\n"
                + "        setLocationRelativeTo(null);\n"
                + "        setVisible(true);\n"
                + "    }\n"
                + "}\n"
        );
        manipulaArquivo.salvarArquivo("src/classeGerada/" + "GUI" + nomeClasse + ".java", codigo);
        for (String i : codigo) {
            System.out.println(i);
        }

    }
}
