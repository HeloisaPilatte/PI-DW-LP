package heloisapilatte_geradorv2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author radames
 */
public class GerarClasseEntidade {

    public GerarClasseEntidade(String caminho) {
        System.out.println(caminho);
        List<String> descricaoEntidade = new ArrayList<>();
        List<String> textoGerado = new ArrayList<>();
        File file = new File(caminho);
        String nomeClasse = file.getName();

        String auxA[] = nomeClasse.split("\\.");
        nomeClasse = auxA[0];
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();

        descricaoEntidade = manipulaArquivo.abrirArquivo(caminho);

        if (descricaoEntidade == null) {
            System.out.println("Não achou o arquivo com o nome e atributos da classe....");
            System.exit(0); //aborta o programa
        }
        for (String s : descricaoEntidade) {
            System.out.println(s);
        }
        int numAtributos = 0;
        String[] nomeAtributos = new String[descricaoEntidade.size()];
        String[] tipoAtributos = new String[descricaoEntidade.size()];
        String[] inicioAtributos = new String[descricaoEntidade.size()];
        String modeloData = "dd/MM/yyyy";

        for (int i = 0; i < descricaoEntidade.size(); i++) {
            numAtributos++;
            String[] aux = descricaoEntidade.get(i).split(";");
            nomeAtributos[i] = aux[0];
            tipoAtributos[i] = aux[1];
            inicioAtributos[i] = aux[2];
            if (aux[1].equals("int")) {
                tipoAtributos[i] = "Integer";
            } else if (aux[1].equals("Int")) {
                tipoAtributos[i] = "Integer";
            } else if (aux[1].equals("Date")) {
                modeloData = "dd/MM/yyyy";

            }
        }

        System.out.println("--------------Larissa ");
        textoGerado.add("package classeGerada;"
                + "import java.util.Date;"
                + "import java.text.SimpleDateFormat;");
        textoGerado.add("public class " + nomeClasse + " {");
        String construir = "";
        String thiz = "";

        for (int i = 0; i < descricaoEntidade.size(); i++) {
            String[] aux = descricaoEntidade.get(i).split(";");
            String ss = "private " + aux[1] + " " + aux[0] + ";";
            if (i != (descricaoEntidade.size() - 1)) {
                construir += aux[1] + " " + aux[0] + ",";

            } else {
                construir += aux[1] + " " + aux[0];
            }
            thiz += "this." + aux[0] + " = " + aux[0] + ";\n";
            textoGerado.add(ss);

        }

        textoGerado.add("\n" + "    " + nomeClasse + "(" + construir + ") {\n" + thiz
                + "       }\n"
                + "\n"
                + "    " + nomeClasse + "() {\n" + "    }");

        STRS strs = new STRS();
        textoGerado.add("private SimpleDateFormat sdf  = new SimpleDateFormat(\"" + modeloData + "\");");
        //boolean
        for (int i = 0; i < descricaoEntidade.size(); i++) {
            String[] aux = descricaoEntidade.get(i).split(";");

            if (aux[1].equals("boolean")) {
                String ss = "public boolean is" + strs.primeiraLetraMaiuscula(aux[0]) + "(){\n" + " return " + aux[0] + ";}\n";
                textoGerado.add(ss);

            }
        }

        //metodos set
        for (int i = 0; i < descricaoEntidade.size(); i++) {
            String[] aux = descricaoEntidade.get(i).split(";");

            String ss = "public void set" + strs.primeiraLetraMaiuscula(aux[0]) + "(" + aux[1]
                    + " " + aux[0] + "){\n" + "this." + aux[0] + "="
                    + aux[0] + ";\n}\n";
            textoGerado.add(ss);
        }
        textoGerado.add("");

        //metodos get
        for (int i = 0; i < descricaoEntidade.size(); i++) {
            String[] aux = descricaoEntidade.get(i).split(";");

            String ss = "public " + aux[1] + " get"
                    + strs.primeiraLetraMaiuscula(aux[0])
                    + "(){\n"
                    + "return this." + aux[0] + ";"
                    + "\n}\n";
            textoGerado.add(ss);
        }
        textoGerado.add("");

        //metodo toString
        String campos = "";
        for (int i = 0; i < descricaoEntidade.size(); i++) {
            String[] aux = descricaoEntidade.get(i).split(";");
            if (aux[1].equals("Date")) {
                campos += "this.sdf.format(" + aux[0] + ")+\";\"+";

            } else {
                campos += "this." + aux[0] + "+\";\"+";

            }
        }
        textoGerado.add("@Override\n"
                + "    public String toString() { return ");
        textoGerado.add(campos.substring(0, campos.length() - 5) + ";\n}\n}");

        manipulaArquivo.salvarArquivo("src/classeGerada/" + nomeClasse + ".java", textoGerado);
    }
}
