/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heloisapilatte_geradorv2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class GerarMArquivo {

    public GerarMArquivo(String caminho) {
        System.out.println(caminho);
        List<String> codigo = new ArrayList<>();
        ManipulaArquivo m = new ManipulaArquivo();
        codigo.add("package classeGerada;"
                +"import java.io.BufferedReader;\n"
                + "import java.io.BufferedWriter;\n"
                + "import java.io.File;\n"
                + "import java.io.FileReader;\n"
                + "import java.io.FileWriter;\n"
                + "import java.util.ArrayList;\n"
                + "import java.util.List;\n"
                + "\n"
                + "public class ManipulaArquivo {\n"
                + "\n"
                + "    public ManipulaArquivo() {\n"
                + "    }\n"
                + "\n"
                + "    // /home/radames/Documentos/texto.txt\n"
                + "    public List<String> abrirArquivo(String caminho) {\n"
                + "         \n"
                + "        List<String> texto = null;\n"
                + "        try {\n"
                + "            //OpenFile\n"
                + "            File file = new File(caminho);\n"
                + "            if (file.exists()) {                \n"
                + "                FileReader arquivo = new FileReader(caminho);\n"
                + "                BufferedReader conteudoDoArquivo = new BufferedReader(arquivo);\n"
                + "                String linha = conteudoDoArquivo.readLine();\n"
                + "                texto = new ArrayList<String>();\n"
                + "                while (linha != null) {\n"
                + "                    texto.add(linha);\n"
                + "                    linha = conteudoDoArquivo.readLine();\n"
                + "                }\n"
                + "                conteudoDoArquivo.close();\n"
                + "            } else {\n"
                + "                return null;\n"
                + "            }\n"
                + "        } catch (Exception e) {//Catch exception if any\n"
                + "            return null;\n"
                + "        }\n"
                + "        return texto;\n"
                + "    }\n"
                + "\n"
                + "    public int salvarArquivo(String caminho, List<String> texto) {\n"
                + "        try {\n"
                + "            // Create file \n"
                + "            FileWriter arquivo = new FileWriter(caminho);\n"
                + "            BufferedWriter conteudoDoArquivo = new BufferedWriter(arquivo);\n"
                + "            for (int i = 0; i < texto.size(); i++) {\n"
                + "                conteudoDoArquivo.write(texto.get(i) + System.lineSeparator());\n"
                + "            }\n"
                + "            conteudoDoArquivo.close();\n"
                + "        } catch (Exception e) {//Catch exception if any\n"
                + "            System.err.println(\"Error: \" + e.getMessage());\n"
                + "            return 1; //houve erro\n"
                + "        }\n"
                + "        return 0;\n"
                + "    }\n"
                + "}\n"
                + "");
        m.salvarArquivo("src/classeGerada/ManipulaArquivo.java", codigo);
            
            
    }
}
