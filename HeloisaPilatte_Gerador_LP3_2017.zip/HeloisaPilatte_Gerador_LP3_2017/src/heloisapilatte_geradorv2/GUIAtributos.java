package heloisapilatte_geradorv2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author radames
 */
public class GUIAtributos extends JFrame {

    private JPanel pnlBotoes;
    private JTable tblAtributos;
    private AtributoTableModel model;
    private final JButton btnAddAtributo = new JButton("Adicionar");
    private final JButton btnUpdAtributo = new JButton("Alterar");
    private final JButton btnDelAtributo = new JButton("Excluir");
    private final JButton btnSave = new JButton("Salvar");
    private final JButton btnAbrir = new JButton("...");
    private final JButton btnGerarClasseEntidade = new JButton("Entidade");
    private final JButton btnGerarClasseControle = new JButton("Controle");
    private final JButton btnGerarClasseGUI = new JButton("GUI");
    private final JButton btnGerarGUIListagem = new JButton("GUI Listagem");
    private final JButton btnGerarClasseDaoG = new JButton("DaoG");
    private final JButton btnGerarClasseDaoE = new JButton("DaoE");
    private final JButton btnGerarSTRS = new JButton("Classe STRS");
    private final JButton btnGerarMArquivo = new JButton("Classe Manipula Arquivo");
    private final JButton btnGerarClasseMain = new JButton("Classe Main");
    private final JButton btnAbrir2 = new JButton("Criar novo txt");
    private Container cp;
    private final JPanel pnNorte = new JPanel(new GridLayout(3, 1));
    private final JPanel pnNorteB = new JPanel(new GridLayout(2, 3));
    private final JPanel pnNorteA = new JPanel(new FlowLayout());
    private final JPanel pnNorteC = new JPanel(new GridLayout(1, 2));
    private final JPanel pnCentro = new JPanel();
    private final JPanel pnSul = new JPanel(new GridLayout(2, 1));
    private final JPanel pnSulA = new JPanel();
    private final JPanel pnSulB = new JPanel();
    private final JLabel lbNome = new JLabel("Nome");
    private final JTextField tfEntidade = new JTextField(35);
    private final JTextField tfNome = new JTextField(5);
    private final JLabel lbTipo = new JLabel("Tipo");
    private final JTextField tfTipo = new JTextField(10);
    private final JLabel lbTamanho = new JLabel("Tamanho/início");
    private final JTextField tfTamanho = new JTextField(10);
    private String caminho = "";
    private ManipulaArquivo manipulaArquivo;
    private List<String> lista = new ArrayList<>();
    private List<Atributo> listaAtributo;
    private JFileChooser caixaDeDialogo = new JFileChooser();
    String tamanho="";
    String tipo="";

    public GUIAtributos() {
        super("Editor de Classe e Atributos - v002");
        initialize();
    }

    private void initialize() {

        manipulaArquivo = new ManipulaArquivo();
        List<String> last = manipulaArquivo.abrirArquivo("UltimaExecucao.dat");// 
        if (last != null) {
            caminho = last.get(0);
            tfEntidade.setText(caminho);
            listaAtributo = new ArrayList();

            lista = manipulaArquivo.abrirArquivo(caminho);
            if (lista != null) {
                tfEntidade.setText(caminho);

                Atributo a;
                for (String string : lista) {
                    String[] aux = string.split(";");
                    if(!aux[1].equals("Date") || !aux[1].equals("boolean")){
                    a = new Atributo(aux[0], aux[1], aux[2]);
                    listaAtributo.add(a);
                    addAtributo(a);
                    }
                    else{
                         a = new Atributo(aux[0], aux[1],aux[2]);
                    listaAtributo.add(a);
                    addAtributo(a);
                    }
                }
                // abre a última pasta no filechooser.
                File file = new File(caminho);
                caixaDeDialogo.setCurrentDirectory(file);
                tfEntidade.setBackground(Color.green);
            } else {
                tfEntidade.setBackground(Color.red);
                addAtributos();
            }
        }
        setSize(800, 600);
        CentroDoMonitorMaior centroDoMonitorMaior = new CentroDoMonitorMaior();
        setLocation(centroDoMonitorMaior.getCentroMonitorMaior(this));
        // addAtributos();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JComboBox<String> comboTipo = new JComboBox<String>();
        comboTipo.addItem("String");
        comboTipo.addItem("Date");
        comboTipo.addItem("int");
        comboTipo.addItem("boolean");
        comboTipo.addItem("long");
        comboTipo.addItem("double");
        
        JComboBox<String> comboTamanho = new JComboBox<String>();
        comboTamanho.addItem("0");
        comboTamanho.addItem("10");
        comboTamanho.addItem("20");
        comboTamanho.addItem("30");
        comboTamanho.addItem("40");
        comboTamanho.addItem("50");
        
        
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnCentro.add(new JScrollPane(getTblAtributos()));

        pnNorteA.add(new JLabel("Entidade"));
        pnNorteA.add(tfEntidade);
        pnNorteA.add(btnAbrir);
        pnNorteA.add(btnAbrir2);
       
        pnNorteB.add(lbNome);
        pnNorteB.add(lbTipo);
        pnNorteB.add(lbTamanho);
        pnNorteB.add(tfNome);
        pnNorteB.add(comboTipo);
        pnNorteB.add(comboTamanho);

        pnNorte.add(pnNorteA);
        pnNorte.add(pnNorteB);
        pnNorte.add(pnNorteC);
        pnNorteC.add(btnAddAtributo);
        pnNorteC.add(btnUpdAtributo);
        pnNorteC.add(btnDelAtributo);

        pnSulA.add(btnSave);
        pnSulB.add(btnGerarClasseEntidade);
        pnSulB.add(btnGerarClasseControle);
        pnSulB.add(btnGerarClasseGUI);
        pnSulB.add(btnGerarGUIListagem);
        pnSulB.add(btnGerarSTRS);
        pnSulB.add(btnGerarMArquivo);
        pnSulB.add(btnGerarClasseMain);
        pnSulB.add(btnGerarClasseDaoG);
        pnSulB.add(btnGerarClasseDaoE);
        pnSul.add(pnSulA);
        pnSul.add(pnSulB);

        setVisible(true);

        btnAddAtributo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamanho = comboTamanho.getSelectedItem().toString();
                tipo = comboTipo.getSelectedItem().toString();
                addAtributo();
            }
        });

        btnUpdAtributo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamanho = comboTamanho.getSelectedItem().toString();
                tipo = comboTipo.getSelectedItem().toString();
                updAtributo();
            }
        });

        btnDelAtributo.addActionListener((ActionEvent e) -> {
            delAtributo();
        });

        btnSave.addActionListener((ActionEvent e) -> {
            List<String> lista = model.getListaAtributosString();
            if (tfEntidade.getText().equals("")) {
                pnSul.setBackground(Color.red);
                tfEntidade.requestFocus();
            }tamanho = comboTamanho.getSelectedItem().toString();
                tipo = comboTipo.getSelectedItem().toString();


            manipulaArquivo.salvarArquivo(tfEntidade.getText(), lista);
        });

        btnAbrir.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                listaAtributo = new ArrayList();
                FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
                caixaDeDialogo.setFileFilter(filter);
                caixaDeDialogo.setFileSelectionMode(JFileChooser.FILES_ONLY);
                if (caixaDeDialogo.showOpenDialog(cp) == JFileChooser.APPROVE_OPTION) {
                    caminho = caixaDeDialogo.getSelectedFile().getAbsolutePath();

                    lista = manipulaArquivo.abrirArquivo(caminho);
                    tfEntidade.setText(caminho);

                    getModel();
                    model.limpar();
                    Atributo a;
                    for (int i = 0; i < lista.size(); i++) {
                        String[] aux = lista.get(i).split(";");
                        a = new Atributo(aux[0], aux[1], aux[2]);
                        System.out.println(a.toString());
                        listaAtributo.add(a);
                    }
                    model.addListaDeAtributos(listaAtributo);
                    tfEntidade.setBackground(Color.green);
                }
                lista = manipulaArquivo.abrirArquivo(tfEntidade.getText());
            }
        });
        btnAbrir2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

               
                String caminho = "Paula.txt";
                File file = new File(caminho);
                if (file.exists()) {
                    System.out.println("EXISTE");
                } else {
                    try {
                        file.createNewFile();
                    } catch (IOException ex) {
                        System.out.println("criado");
                    }
                }
                
            }
        });

        btnGerarClasseEntidade.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                GerarClasseEntidade gerarClasseEntidade = new GerarClasseEntidade(caminho);
            }
        });

        btnGerarClasseControle.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                GerarClasseDeControle gerarClasseDeControle = new GerarClasseDeControle(caminho);
            }
        });
        btnGerarMArquivo.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                GerarMArquivo gma = new GerarMArquivo(caminho);
            }
        });
        btnGerarSTRS.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                GerarSTRS gerarSTRS = new GerarSTRS(caminho);
            }
        });
        btnGerarClasseGUI.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                GerarGUI gerarGUI = new GerarGUI(caminho);
            }
        });
        btnGerarClasseMain.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                GerarClasseMain gerarClasseMain = new GerarClasseMain(caminho);
            }
        });
        
        btnGerarClasseDaoG.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                GerarClasseDaoG gerarClasseDaoG = new GerarClasseDaoG(caminho);
            }
        });

        btnGerarClasseDaoE.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                GerarClasseDaoE gerarClasseDaoE = new GerarClasseDaoE(caminho);
            }
        });
        btnGerarGUIListagem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                GerarGUIListagem gerarGUIListagem = new GerarGUIListagem(caminho);
                GerarMinhaJOptionPane gerarMinhaJOptionPane = new GerarMinhaJOptionPane();
            }
        });

        tblAtributos.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Atributo a = model.getAtributo(tblAtributos.getSelectedRow());
                tfNome.setText(a.getNome());
                tfTipo.setText(a.getTipo());
                tfTamanho.setText(String.valueOf(a.getTamanho()));
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        //listenner ao fechar a janela
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                last.clear();
                caminho = tfEntidade.getText();
                System.out.println("caminho " + caminho);
                last.add(caminho);
                manipulaArquivo.salvarArquivo("UltimaExecucao.dat", last);
                // Sai do sistema  
                System.exit(0);
            }
        });
        /*
         String aux;
         if (caminho.substring(caminho.length() - 3, caminho.length()).equals("txt")) {
         aux = "";
         } else {
         aux = ".txt";
         } 
         */

    }

    private JTable getTblAtributos() {
        if (tblAtributos == null) {
            tblAtributos = new JTable();
            tblAtributos.setModel(new AtributoTableModel());
        }
        return tblAtributos;
    }

    private AtributoTableModel getModel() {
        if (model == null) {
            model = (AtributoTableModel) getTblAtributos().getModel();
        }
        return model;
    }

    private Atributo setAtributo(String nome, String tipo, String tamanho) {
        Atributo atributo = new Atributo();
        atributo.setNome(nome);
        atributo.setTipo(tipo);
        atributo.setTamanho(tamanho);
        return atributo;
    }

    private List<Atributo> autoAtributos() {
        List<Atributo> atributos = new ArrayList<Atributo>();
        Atributo atributo = new Atributo();
        atributo.setNome("id");
        atributo.setTipo("int");
        atributo.setTamanho("0");
        atributos.add(atributo);

        atributo = new Atributo();
        atributo.setNome("nome");
        atributo.setTipo("String");
        atributo.setTamanho("45");
        atributos.add(atributo);

        return atributos;
    }

    private void addAtributo() {
        getModel().addAtributo(setAtributo(tfNome.getText(), tipo, tamanho));
    }

    private void addAtributo(Atributo a) {
        getModel().addAtributo(a);
    }

    private void addAtributos() {
        getModel().addListaDeAtributos(autoAtributos());
    }

    private void updAtributo() {
        Atributo a = new Atributo(tfNome.getText(),tipo, tamanho);
        model.setAtributo(tblAtributos.getSelectedRow(), a);

    }

    private void delAtributo() {
        if (tblAtributos.getSelectedRow() >= 0) {
            model.removeAtributo(tblAtributos.getSelectedRow());
        }
    }

}
