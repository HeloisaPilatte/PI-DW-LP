/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heloisapilatte_geradorv2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hello
 */
public class GerarClasseDaoE {

    public GerarClasseDaoE(String caminho) {
        System.out.println(caminho);
        List<String> descricaoEntidade = new ArrayList<>();
        List<String> codigo = new ArrayList<>();
        File file = new File(caminho);

        String nomeClasse = file.getName();

        String auxA[] = nomeClasse.split("\\.");
        nomeClasse = auxA[0];
        String nomeClasse1 = "DAO" + nomeClasse;
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        STRS strs = new STRS();
        descricaoEntidade = manipulaArquivo.abrirArquivo(caminho);

        if (descricaoEntidade == null) {
            System.out.println("Não achou o arquivo com o nome e atributos da classe....");
            System.exit(0); //aborta o programa
        }
        int numAtributos = 0;
        String[] nomeAtributos = new String[descricaoEntidade.size()];
        String[] tipoAtributos = new String[descricaoEntidade.size()];
        String[] inicioAtributos = new String[descricaoEntidade.size()];

        for (int i = 0; i < descricaoEntidade.size(); i++) {
            numAtributos++;
            String[] aux = descricaoEntidade.get(i).split(";");
            nomeAtributos[i] = aux[0];
            tipoAtributos[i] = aux[1];
            inicioAtributos[i] = aux[2];
            if (aux[1].equals("int")) {
                tipoAtributos[i] = "Integer";
            }
        }

        codigo.add("package DAOs;\n"
                + "\n"
                + "\n"
                + "import Entidades."+nomeClasse+";\n"
                + "import java.util.ArrayList;\n"
                + "import java.util.List;");

        codigo.add("public class DAO" + nomeClasse + " extends DAOGenerico<" + nomeClasse + "> {");

        codigo.add("public DAO" + nomeClasse + "() {\n"
                + "        super(" + nomeClasse + ".class);\n"
                + "    }");

        codigo.add("public int auto" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + nomeClasse + "() {");
        codigo.add("Integer a = (Integer) em.createQuery(\"SELECT MAX(e." + nomeAtributos[0] + nomeClasse + ") FROM " + nomeClasse + " e \").getSingleResult();");
        codigo.add("if (a != null) {\n"
                + "            return a + 1;\n"
                + "        } else {\n"
                + "            return 1;\n"
                + "        }\n"
                + "    }");

        String nom1 = tipoAtributos[1];
        if (nom1.equals("String")) {
            codigo.add(" public List<" + nomeClasse + "> listBy" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + "(" + tipoAtributos[1] + " " + nomeAtributos[1] + ") {");
            codigo.add("return em.createQuery(\"SELECT e FROM " + nomeClasse + " e WHERE e." + nomeAtributos[1] + nomeClasse + " LIKE :" + nomeAtributos[1] + "\").setParameter(\"" + nomeAtributos[1] + "\", \"%\" + " + nomeAtributos[1] + " + \"%\").getResultList();\n"
                    + "    }");
        } else if (nom1.equals("Integer") || nom1.equals("long")) {
            codigo.add("public List<" + nomeClasse + "> listBy" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + "(int " + nomeAtributos[1] + ") {");
            codigo.add(" return em.createQuery(\"SELECT e FROM" + nomeClasse + "  e WHERE e." + nomeAtributos[1] + nomeClasse + " = :" + nomeAtributos[1] + "\").setParameter(\"" + nomeAtributos[1] + "\", " + nomeAtributos[1] + ").getResultList();\n"
                    + "    }");

        }

        String nom2 = tipoAtributos[0];
        if (nom2.equals("Integer") || nom2.equals("long")) {
            codigo.add("public List<" + nomeClasse + "> listBy" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "(int " + nomeAtributos[0] + ") {");
            codigo.add(" return em.createQuery(\"SELECT e FROM" + nomeClasse + "  e WHERE e." + nomeAtributos[0] + nomeClasse + " = :" + nomeAtributos[0] + "\").setParameter(\"" + nomeAtributos[0] + "\", " + nomeAtributos[0] + ").getResultList();\n"
                    + "    }");
        } else if (nom2.equals("String")) {
            codigo.add(" public List<" + nomeClasse + "> listBy" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "(" + tipoAtributos[0] + " " + nomeAtributos[0] + ") {");
            codigo.add("return em.createQuery(\"SELECT e FROM " + nomeClasse + " e WHERE e." + nomeAtributos[0] + nomeClasse + " LIKE :" + nomeAtributos[0] + "\").setParameter(\"" + nomeAtributos[0] + "\", \"%\" + " + nomeAtributos[0] + " + \"%\").getResultList();\n"
                    + "    }");

        }

        codigo.add("public List<" + nomeClasse + "> listInOrder" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + "() {");
        codigo.add(" return em.createQuery(\"SELECT e FROM " + nomeClasse + " e ORDER BY e." + nomeAtributos[1] + nomeClasse + "\").getResultList();\n"
                + "    }");

        codigo.add("public List<" + nomeClasse + "> listInOrder" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "() {");
        codigo.add("return em.createQuery(\"SELECT e FROM " + nomeClasse + " e ORDER BY e." + nomeAtributos[0] + nomeClasse + "\").getResultList();\n"
                + "    }");

       
        
        
        
        
        
        codigo.add("public List<String> listInOrderNomeStrings(String qualOrdem) {");
        codigo.add("List<"+nomeClasse+"> lf;");
        codigo.add("if (qualOrdem.equals(\"" + nomeAtributos[0] + "\")) {");
        codigo.add("lf = listInOrder" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "();");
        codigo.add("} else {");
        codigo.add("lf = listInOrder" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + "();}");

        codigo.add("List<String> ls = new ArrayList<>();");
        codigo.add("for (int i = 0; i < lf.size(); i++) {");
        codigo.add("ls.add(lf.get(i).get" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + nomeClasse + "() + \"-\" + lf.get(i).get" + strs.primeiraLetraMaiuscula(nomeAtributos[1]) + nomeClasse + "());}");
        codigo.add("return ls;}}");

        manipulaArquivo.salvarArquivo("src/classeGerada/" + nomeClasse1 + ".java", codigo);

    }

}
