package heloisapilatte_geradorv2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GerarClasseDeControle {
    
    String nomeClasse;
    
    public GerarClasseDeControle(String caminho) {
        STRS strs = new STRS();
        System.out.println("Caminho do arquivo base =>" + caminho);
        
        File file = new File(caminho);
        if (file.exists()) {
            //  System.out.println("Ok, achou...");
            nomeClasse = file.getName();
            String[] aux = nomeClasse.split("\\.");
            nomeClasse = aux[0];
            System.out.println("Nome da classe=> " + nomeClasse);
        } else {
            System.out.println("Deu errado, não achou o arquivo");
            System.exit(0);
        }
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        List<String> descricaoEntidade = new ArrayList<>();

        descricaoEntidade = manipulaArquivo.abrirArquivo(caminho);

        if (descricaoEntidade == null) {
            System.out.println("Não achou o arquivo com o nome e atributos da classe....");
            System.exit(0); //aborta o programa
        }
        String[] nomeAtributos = new String[descricaoEntidade.size()];
        String[] tipoAtributos = new String[descricaoEntidade.size()];
           
        for (int i = 0; i < descricaoEntidade.size(); i++) {
            
            String[] aux = descricaoEntidade.get(i).split(";");
            nomeAtributos[i] = aux[0];
            tipoAtributos[i] = aux[1];
            }
        
//        List<String> de = new ManipulaArquivo().abrirArquivo(caminho);

  //      for (int i = 0; i < de.size(); i++) {
  //        System.out.println(de.get(i));
  //  }
        List<String> codigo = new ArrayList<>();
        
        codigo.add("package classeGerada;");
        
        codigo.add(
                "import java.util.ArrayList;\n"
                + "import java.util.List;");
        
        codigo.add("public class Controle" + nomeClasse + "{");
        
        codigo.add("List<" + nomeClasse + "> lista = new ArrayList<>();");
        
        codigo.add("");
        codigo.add("public void inserir(" + nomeClasse + " "
                + nomeClasse.toLowerCase() + "){");
        codigo.add("lista.add(" + nomeClasse.toLowerCase() + ");\n}");
        codigo.add("public "+nomeClasse+" buscar("+nomeClasse+" "+nomeClasse.toLowerCase()+") {\n"
                + "        for (int i = 0; i < lista.size(); i++) {\n");
        String auxiliarExtra = "";
        auxiliarExtra = "            if (" + nomeClasse.toLowerCase() + ".get" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "().equals(lista.get(i).get" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "())) {\n";
        System.out.println("============================================>"+tipoAtributos[0]);
        if (tipoAtributos[0].equals("String")) {
            codigo.add(auxiliarExtra);
         
        } else {
            codigo.add("            if (" + nomeClasse.toLowerCase() + ".get" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "() == lista.get(i).get" + strs.primeiraLetraMaiuscula(nomeAtributos[0]) + "()) {\n");

        }        
        codigo.add("                return lista.get(i);\n"
                + "            }\n"
                + "        }\n"
                + "        return null;\n"
                + "    }\n"
                + "\n"
                + "    public void alterar("+nomeClasse+" "+nomeClasse.toLowerCase()+"Original, "+nomeClasse+" "+nomeClasse.toLowerCase()+"Modificado) {\n"
                + "        lista.set(lista.indexOf("+nomeClasse.toLowerCase()+"Original), "+nomeClasse.toLowerCase()+"Modificado);\n"
                + "    }\n"
                + "\n"
                + "    public void remover("+nomeClasse+" "+nomeClasse.toLowerCase()+") {\n"
                + "        lista.remove("+nomeClasse.toLowerCase()+");\n"
                + "    }\n"
                + "\n"
                + "    public void listar() {\n"
                + "        for ("+nomeClasse+" elemento : lista) {\n"
                + "            System.out.println(elemento.toString());\n"
                + "        }\n"
                + "    }\n"
                + "\n"
                + "    public List<"+nomeClasse+"> getLista() {\n"
                + "        return lista;\n"
                + "    }\n"
                + "}\n"
                + "") ;
        manipulaArquivo.salvarArquivo("src/classeGerada/Controle" + nomeClasse + ".java", codigo);
        
        
//imprime o que foi gerado
        for (int i = 0; i < codigo.size(); i++) {
            System.out.println(codigo.get(i));
        }
        
    }
    
}
