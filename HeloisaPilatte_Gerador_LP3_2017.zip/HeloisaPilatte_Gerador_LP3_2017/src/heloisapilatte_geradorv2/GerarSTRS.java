/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heloisapilatte_geradorv2;

import com.sun.org.apache.bcel.internal.generic.AALOAD;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class GerarSTRS {
    
    public GerarSTRS(String caminho) {
        
        List<String> codigo = new ArrayList<>();
        ManipulaArquivo m = new ManipulaArquivo();
        codigo.add("package classeGerada;\n"
                + "public class STRS {\n"
                + "\n"
                + "    public String primeiraLetraMaiuscula(String s) {\n"
                + "        String plmaiuscula = s.substring(0, 1).toUpperCase() + s.substring(1);\n"
                + "        return plmaiuscula;\n"
                + "    }\n"
                + "}\n"
                + "");
        m.salvarArquivo("src/classeGerada/STRS.java", codigo);
    }
}
