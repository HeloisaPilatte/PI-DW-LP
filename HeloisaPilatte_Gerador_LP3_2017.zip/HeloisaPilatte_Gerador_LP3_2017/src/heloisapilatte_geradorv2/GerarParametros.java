/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heloisapilatte_geradorv2;

import static com.sun.glass.ui.Cursor.setVisible;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author Usuario
 */
public class GerarParametros {
    public class GUI extends JFrame {
        
        Container cp;
        
        public GUI() {
            setSize(800, 600);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            cp = getContentPane();
            cp.setLayout(new BorderLayout());
            setTitle("Colocar Atributos");
            
            setVisible(true);
        }
    }
}