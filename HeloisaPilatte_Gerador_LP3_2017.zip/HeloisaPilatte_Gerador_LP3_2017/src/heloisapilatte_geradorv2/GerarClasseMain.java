/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heloisapilatte_geradorv2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class GerarClasseMain {

    public GerarClasseMain(String caminho) {
        System.out.println(caminho);
        List<String> descricaoEntidade = new ArrayList<>();
        List<String> codigo = new ArrayList<>();
        File file = new File(caminho);
        String nomeClasse = file.getName();

        String auxA[] = nomeClasse.split("\\.");
        nomeClasse = auxA[0];
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        STRS strs = new STRS();
        descricaoEntidade = manipulaArquivo.abrirArquivo(caminho);

        if (descricaoEntidade == null) {
            System.out.println("Não achou o arquivo com o nome e atributos da classe....");
            System.exit(0); //aborta o programa
        }
        codigo.add("package classeGerada;\n"
                + "\n"
                + "/**\n"
                + " *\n"
                + " * @author Usuario\n"
                + " */\n"
                + "import java.text.ParseException;"
                + "public class Main {\n"
                + "\n"
                + "    /**\n"
                + "     * @param args the command line arguments\n"
                + "     */\n"
                + "    public static void main(String[] args) throws ParseException {\n");
                
        codigo.add("GUI" + nomeClasse + " gui = new GUI" + nomeClasse + "();"
                + "    }\n"
                + "    \n" +
        "}");
        manipulaArquivo.salvarArquivo("C:/Users/Heloisa/Documents/NetBeansProjects/ArrumandoG_1/src/arrumandog/Main.java", codigo);
    }
}
